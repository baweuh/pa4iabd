"""
src/agent.py — Agent : énergie, cycle de vie, raycasts 16×360°, déplacement,
reproduction asexuée. CDC §4 + §2.3.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from .config import AgentsConfig, MutationsConfig
from .environment import Environment
from .genome import Genome, InnovationCounter
from .network import NeuralNetwork

if TYPE_CHECKING:
    pass


class Agent:
    """
    Un agent dans la simulation ALife.
    CDC §4 : Propriétés physiques, cycle de vie, système d'énergie,
    perception via 16 raycasts 360°.
    """

    def __init__(
        self,
        genome: Genome,
        x: float,
        y: float,
        energy: float,
        cfg_agents: AgentsConfig,
        cfg_mutations: MutationsConfig,
        rng: random.Random,
        is_bootstrap: bool = False,
    ) -> None:
        self.genome = genome
        self.network = NeuralNetwork(genome)
        self.x = x
        self.y = y
        self.vx = 0.0
        self.vy = 0.0
        self.energy = energy
        self.cfg = cfg_agents
        self.cfg_mut = cfg_mutations
        self.rng = rng

        # Cycle de vie
        self.age = 0
        self.alive = True
        self.is_bootstrap = is_bootstrap

        # Compteurs
        self.food_eaten = 0  # pommes mangées dans cette vie (cumulatif)
        self.children_count = 0

        # Raycasts (pour le rendu)
        self.rays: list[tuple[float, float, float]] = []  # [(end_x, end_y, type)]

        # Inputs du réseau : 33 (16 rays × 2 + 1 énergie) (CDC §5.5)
        self.input_size = cfg_agents.num_rays * 2 + 1

    # ══════════════════════════════════════════════════════════════════
    #  RAYCASTS  (CDC §4.4)
    # ══════════════════════════════════════════════════════════════════

    def compute_raycasts(self, env: Environment) -> np.ndarray:
        """
        Calcule 16 raycasts répartis uniformément à 360° (espacement 22.5°).
        Retourne les inputs du réseau (33 valeurs) : 16 distances + 16 types + 1 énergie.

        CDC §4.4 :
        - Valeurs retournées : 2 par ray (distance normalisée [0→1] + type encodé)
        - Encodage du type : 0.0 = rien | 0.5 = pomme | 1.0 = mur
        - Comportement : First-hit (occlusion naturelle)
        """
        num_rays = self.cfg.num_rays
        ray_range = self.genome.ray_range
        food_radius = self.cfg.food_radius

        inputs = np.zeros(self.input_size, dtype=np.float64)
        self.rays = []
        step = 2.0 * math.pi / num_rays

        # Pré-filtrer les pommes actives dans le rayon de vision
        max_dist_sq = (ray_range + food_radius + 5) ** 2
        active_apples = [
            a for a in env.apples
            if a.respawn_at_tick < 0
            and (a.x - self.x) ** 2 + (a.y - self.y) ** 2 <= max_dist_sq
        ]

        for i in range(num_rays):
            angle = i * step
            dx = math.cos(angle)
            dy = math.sin(angle)

            # ── Intersection mur la plus proche ──
            wall_t = ray_range + 1.0
            if dx < -1e-9:
                t = -self.x / dx
                if 0 < t < wall_t:
                    wall_t = t
            if dx > 1e-9:
                t = (env.width - self.x) / dx
                if 0 < t < wall_t:
                    wall_t = t
            if dy < -1e-9:
                t = -self.y / dy
                if 0 < t < wall_t:
                    wall_t = t
            if dy > 1e-9:
                t = (env.height - self.y) / dy
                if 0 < t < wall_t:
                    wall_t = t

            # ── Intersection pomme la plus proche ──
            food_t = ray_range + 1.0
            hit_food = False
            detect_r_sq = (food_radius + 10) ** 2  # rayon de détection élargi pour meilleur food-finding

            for apple in active_apples:
                vfx = apple.x - self.x
                vfy = apple.y - self.y
                proj = vfx * dx + vfy * dy
                if proj <= 0 or proj >= min(wall_t, food_t):
                    continue
                px = self.x + proj * dx
                py = self.y + proj * dy
                if (px - apple.x) ** 2 + (py - apple.y) ** 2 <= detect_r_sq:
                    food_t = proj
                    hit_food = True

            # ── Résolution : que voit ce rayon ? ──
            if hit_food and food_t < wall_t:
                dist = food_t
                kind = 0.5  # pomme
            elif wall_t <= ray_range:
                dist = wall_t
                kind = 1.0  # mur
            else:
                dist = ray_range
                kind = 0.0  # rien

            # Encodage (CDC §5.5)
            inputs[i * 2] = wall_t / ray_range if wall_t <= ray_range else 1.0     # Distance Mur
            inputs[i * 2 + 1] = food_t / ray_range if (hit_food and food_t < wall_t) else 1.0 # Distance Pomme
            self.rays.append((
                self.x + dist * dx,
                self.y + dist * dy,
                kind,
            ))

        # Input 32 : énergie normalisée [0.0 → 1.0] (CDC §5.5)
        inputs[num_rays * 2] = min(self.energy / self.cfg.max_energy, 1.0)

        return inputs

    # ══════════════════════════════════════════════════════════════════
    #  DÉPLACEMENT  (CDC §4.1 + §2.4)
    # ══════════════════════════════════════════════════════════════════

    def move(self, env: Environment) -> None:
        """
        Met à jour la position de l'agent.
        CDC §2.4 : outputs (vx, vy) normalisés après sortie.
        speed = min(‖(vx,vy)‖, max_speed), direction = (vx,vy) / ‖(vx,vy)‖
        → évite l'avantage diagonal (×1.41).
        """
        max_speed = self.cfg.max_speed

        # La vitesse est déjà dans self.vx, self.vy (après forward pass)
        # Normalisation : limiter la norme à max_speed
        speed = math.sqrt(self.vx ** 2 + self.vy ** 2)
        if speed > max_speed:
            scale = max_speed / speed
            self.vx *= scale
            self.vy *= scale

        # Nouvelle position
        new_x = self.x + self.vx
        new_y = self.y + self.vy

        # Bloquer sur les murs (CDC §3.1 : murs durs infranchissables)
        radius = self.cfg.agent_radius
        self.x, self.y = env.clamp_position(new_x, new_y, radius)

    def think(self, inputs: np.ndarray) -> None:
        """Forward pass du réseau de neurones → met à jour vx, vy."""
        outputs = self.network.activate(inputs)
        self.vx = outputs[0]
        self.vy = outputs[1]

    # ══════════════════════════════════════════════════════════════════
    #  ÉNERGIE  (CDC §4.3)
    # ══════════════════════════════════════════════════════════════════

    def apply_energy_drain(self, env: Environment) -> None:
        """Applique le drain énergétique : base + zone pénalité (CDC §6.2 étape 5)."""
        drain = self.cfg.base_drain_rate
        drain += env.wall_penalty_drain(self.x, self.y)
        self.energy -= drain

    def eat(self, food_energy: float) -> None:
        """L'agent mange une pomme."""
        self.energy += food_energy
        self.food_eaten += 1

    # ══════════════════════════════════════════════════════════════════
    #  CYCLE DE VIE  (CDC §4.2)
    # ══════════════════════════════════════════════════════════════════

    def is_dead(self) -> bool:
        """Vérifie les conditions de mort (CDC §4.2)."""
        if self.energy <= 0:
            return True
        if self.age >= self.cfg.max_lifespan:
            return True
        return False

    def is_dying(self) -> bool:
        """Indicateur visuel : dans les derniers lifespan_warning_ticks ticks."""
        return self.age >= self.cfg.max_lifespan - self.cfg.lifespan_warning_ticks

    def can_reproduce(self) -> bool:
        """Vérifie si l'agent peut se reproduire (CDC §2.3)."""
        return self.energy >= self.cfg.reproduction_threshold

    # ══════════════════════════════════════════════════════════════════
    #  REPRODUCTION ASEXUÉE  (CDC §2.3)
    # ══════════════════════════════════════════════════════════════════

    def reproduce(self, env: Environment) -> Agent:
        """
        Crée un enfant par reproduction asexuée.
        CDC §2.3 :
        1. Deep copy du génome parent + mutations
        2. Parent : énergie → parent_energy_after_repro
        3. Enfant : énergie → child_initial_energy
        4. Spawn enfant : position aléatoire dans rayon 50–100 px du parent
        """
        # Cloner le génome et appliquer les mutations
        child_genome = self.genome.deep_copy()
        child_genome.mutate(self.cfg_mut)

        # Mettre à jour l'énergie du parent
        self.energy = self.cfg.parent_energy_after_repro
        self.children_count += 1

        # Position de l'enfant : rayon de 50–100 px autour du parent
        spawn_radius = self.cfg.spawn_radius_child
        for _ in range(50):
            angle = self.rng.uniform(0, 2 * math.pi)
            dist = self.rng.uniform(50, spawn_radius)
            child_x = self.x + dist * math.cos(angle)
            child_y = self.y + dist * math.sin(angle)

            # Vérifier : hors zone pénalité et hors mur
            if env.is_valid_spawn(child_x, child_y, self.cfg.agent_radius):
                child_x, child_y = env.clamp_position(child_x, child_y, self.cfg.agent_radius)
                break
        else:
            # Fallback : même position que le parent
            child_x, child_y = self.x, self.y

        child = Agent(
            genome=child_genome,
            x=child_x,
            y=child_y,
            energy=self.cfg.child_initial_energy,
            cfg_agents=self.cfg,
            cfg_mutations=self.cfg_mut,
            rng=self.rng,
            is_bootstrap=False,
        )

        return child

    # ══════════════════════════════════════════════════════════════════
    #  UTILITAIRES
    # ══════════════════════════════════════════════════════════════════

    def tick(self) -> None:
        """Incrémente l'âge de l'agent d'un tick."""
        self.age += 1