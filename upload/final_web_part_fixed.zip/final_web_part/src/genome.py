"""
src/genome.py — Représentation génomique, mutations, innovation counter, sérialisation JSON.
CDC §2.1–2.3 : Génome, NodeGene, ConnectionGene, opérateurs de mutation,
reproduction asexuée, innovation tracking par compteur global.
"""

from __future__ import annotations

import copy
import json
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


# ═══════════════════════════════════════════════════════════════════════
#  Innovation counter (global, auto-incrémenté)
# ═══════════════════════════════════════════════════════════════════════

class InnovationCounter:
    """Compteur global auto-incrémenté. Pas de lookup table — la reproduction
    asexuée ne nécessite pas d'alignement de génomes (CDC §2.1)."""

    _instance: InnovationCounter | None = None
    _value: int = 0

    def __new__(cls) -> InnovationCounter:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @property
    def next_id(self) -> int:
        self._value += 1
        return self._value

    @property
    def current(self) -> int:
        return self._value

    def reset(self) -> None:
        self._value = 0


# ═══════════════════════════════════════════════════════════════════════
#  NodeGene / ConnectionGene
# ═══════════════════════════════════════════════════════════════════════

class NodeType(Enum):
    INPUT = "INPUT"
    HIDDEN = "HIDDEN"
    OUTPUT = "OUTPUT"


@dataclass
class NodeGene:
    id: int
    type: NodeType
    activation: str = "tanh"  # tanh | sigmoid — paramétrable par YAML


@dataclass
class ConnectionGene:
    in_node_id: int
    out_node_id: int
    weight: float
    enabled: bool = True
    innovation_id: int = 0

    def key(self) -> tuple[int, int]:
        return (self.in_node_id, self.out_node_id)


# ═══════════════════════════════════════════════════════════════════════
#  Genome
# ═══════════════════════════════════════════════════════════════════════

class Genome:
    """
    Génome encodant un réseau de neurones feedforward (DAG).
    CDC §2.1 : initial fully connected, poids ∈ [-1, 1].
    """

    def __init__(
        self,
        num_inputs: int,
        num_outputs: int,
        rng: random.Random | None = None,
    ) -> None:
        self.num_inputs = num_inputs
        self.num_outputs = num_outputs
        self._rng = rng or random.Random()
        
        self.ray_range = self._rng.uniform(50.0, 300.0)

        self.nodes: dict[int, NodeGene] = {}
        self.connections: dict[tuple[int, int], ConnectionGene] = {}
        self._next_hidden_id: int = num_inputs + num_outputs
        
        self._build_fully_connected()

    # ── Bootstrap : fully connected ──────────────────────────────────

    def _build_fully_connected(self) -> None:
        """Crée le génome initial : fully connected, poids ∈ [-1, 1]."""
        # Input nodes : ids 0 .. num_inputs-1
        for i in range(self.num_inputs):
            self.nodes[i] = NodeGene(id=i, type=NodeType.INPUT)

        # Output nodes : ids num_inputs .. num_inputs+num_outputs-1
        for i in range(self.num_outputs):
            oid = self.num_inputs + i
            self.nodes[oid] = NodeGene(id=oid, type=NodeType.OUTPUT)

        # Connexions input → output
        ic = InnovationCounter()
        for i in range(self.num_inputs):
            for j in range(self.num_outputs):
                oid = self.num_inputs + j
                key = (i, oid)
                w = self._rng.uniform(-1.0, 1.0)
                self.connections[key] = ConnectionGene(
                    in_node_id=i,
                    out_node_id=oid,
                    weight=w,
                    enabled=True,
                    innovation_id=ic.next_id,
                )

    # ── Propriétés dérivées ──────────────────────────────────────────

    @property
    def input_ids(self) -> list[int]:
        return [n.id for n in self.nodes.values() if n.type == NodeType.INPUT]

    @property
    def output_ids(self) -> list[int]:
        return [n.id for n in self.nodes.values() if n.type == NodeType.OUTPUT]

    @property
    def hidden_ids(self) -> list[int]:
        return [n.id for n in self.nodes.values() if n.type == NodeType.HIDDEN]

    @property
    def enabled_connections(self) -> list[ConnectionGene]:
        return [c for c in self.connections.values() if c.enabled]

    @property
    def connection_count(self) -> int:
        """Nombre de connexions actives."""
        return sum(1 for c in self.connections.values() if c.enabled)

    # ── Deep copy ────────────────────────────────────────────────────

    def deep_copy(self) -> Genome:
        """Clone profond du génome (pour reproduction asexuée)."""
        g = Genome.__new__(Genome)
        g.num_inputs = self.num_inputs
        g.num_outputs = self.num_outputs
        g._rng = self._rng  # le parent du child utilise le même rng
        g._next_hidden_id = self._next_hidden_id
        
        g.ray_range = self.ray_range

        g.nodes = {nid: NodeGene(n.id, n.type, n.activation) for nid, n in self.nodes.items()}
        g.connections = {
            k: ConnectionGene(c.in_node_id, c.out_node_id, c.weight, c.enabled, c.innovation_id)
            for k, c in self.connections.items()
        }
        return g

    # ══════════════════════════════════════════════════════════════════
    #  MUTATIONS  (CDC §2.2 — toutes les probabilités configurables en YAML)
    # ══════════════════════════════════════════════════════════════════

    def mutate(self, cfg) -> None:
        """Applique les mutations stochastiques au génome.
        cfg = MutationsConfig (dataclass depuis YAML)."""
        rng = self._rng

        # 1. Mutation de poids (80 % de chance globale)
        if rng.random() < cfg.mutate_weights_prob:
            self._mutate_weights(cfg)

        # 2. Ajouter une connexion (5 %)
        if rng.random() < cfg.add_connection_prob:
            self._mutate_add_connection()

        # 3. Ajouter un nœud (3 %)
        if rng.random() < cfg.add_node_prob:
            self._mutate_add_node()

        # 4. Retirer une connexion (5 %)
        if rng.random() < cfg.remove_connection_prob:
            self._mutate_remove_connection()

        # 5. Retirer un nœud hidden (2 %)
        if rng.random() < cfg.remove_node_prob:
            self._mutate_remove_node()

        # 6. Toggle connexion (inclus — chaque connexion disabled a une chance)
        self._mutate_toggle_connections()

    def _mutate_weights(self, cfg) -> None:
        """Perturbe ou réinitialise chaque poids."""
        rng = self._rng
        for conn in self.connections.values():
            r = rng.random()
            if r < cfg.weight_perturb_prob:
                # Perturbation gaussienne
                conn.weight += rng.gauss(0, cfg.weight_sigma)
            elif r < cfg.weight_perturb_prob + cfg.weight_reset_prob:
                # Réinitialisation aléatoire
                conn.weight = rng.uniform(-1.0, 1.0)
                
        if rng.random() < cfg.weight_perturb_prob:
            # On applique une légère variation gaussienne (écart-type de 15 pixels par ex.)
            self.ray_range += rng.gauss(0, 15.0)
            # On s'assure que la vision reste dans des limites raisonnables (ex: min 20, max 500)
            self.ray_range = max(20.0, min(self.ray_range, 500.0))

    def _mutate_add_connection(self) -> None:
        """Relie deux nœuds non connectés. Vérification DAG : si cycle →
        essayer direction inverse → sinon abandonner (CDC §2.2)."""
        rng = self._rng
        all_ids = list(self.nodes.keys())

        # Essayer jusqu'à 10 paires aléatoires
        for _ in range(10):
            a, b = rng.sample(all_ids, 2)
            # On ne connecte jamais vers un INPUT
            if self.nodes[b].type == NodeType.INPUT:
                continue
            key_ab = (a, b)
            key_ba = (b, a)
            if key_ab not in self.connections and key_ba not in self.connections:
                # Vérifier DAG dans la direction a→b
                if not self._would_create_cycle(a, b):
                    ic = InnovationCounter()
                    self.connections[key_ab] = ConnectionGene(
                        in_node_id=a,
                        out_node_id=b,
                        weight=rng.uniform(-1.0, 1.0),
                        enabled=True,
                        innovation_id=ic.next_id,
                    )
                    return
                # Vérifier DAG dans la direction b→a
                elif not self._would_create_cycle(b, a):
                    ic = InnovationCounter()
                    self.connections[key_ba] = ConnectionGene(
                        in_node_id=b,
                        out_node_id=a,
                        weight=rng.uniform(-1.0, 1.0),
                        enabled=True,
                        innovation_id=ic.next_id,
                    )
                    return
        # Abandon silencieux si aucune paire valide trouvée

    def _mutate_add_node(self) -> None:
        """Coupe une connexion existante, insère un nœud hidden.
        Crée 2 nouvelles connexions (poids initialisés à 1.0 et à celui
        de la connexion coupée) (CDC §2.2)."""
        enabled = [c for c in self.connections.values() if c.enabled]
        if not enabled:
            return

        rng = self._rng
        conn = rng.choice(enabled)

        # Désactiver l'ancienne connexion
        conn.enabled = False

        # Nouveau nœud hidden
        new_id = self._next_hidden_id
        self._next_hidden_id += 1
        self.nodes[new_id] = NodeGene(id=new_id, type=NodeType.HIDDEN)

        ic = InnovationCounter()

        # Connexion in → new (poids 1.0)
        key_in = (conn.in_node_id, new_id)
        self.connections[key_in] = ConnectionGene(
            in_node_id=conn.in_node_id,
            out_node_id=new_id,
            weight=1.0,
            enabled=True,
            innovation_id=ic.next_id,
        )

        # Connexion new → out (poids = ancien poids)
        key_out = (new_id, conn.out_node_id)
        self.connections[key_out] = ConnectionGene(
            in_node_id=new_id,
            out_node_id=conn.out_node_id,
            weight=conn.weight,
            enabled=True,
            innovation_id=ic.next_id,
        )

    def _mutate_remove_connection(self) -> None:
        """Retire une connexion. Priorité aux connexions disabled."""
        rng = self._rng

        # Priorité : connexions disabled d'abord
        disabled = [c for c in self.connections.values() if not c.enabled]
        if disabled and rng.random() < 0.7:
            conn = rng.choice(disabled)
            del self.connections[conn.key()]
            return

        enabled = [c for c in self.connections.values() if c.enabled]
        # Ne pas supprimer la dernière connexion
        if len(enabled) <= 1:
            return
        conn = rng.choice(enabled)
        del self.connections[conn.key()]

    def _mutate_remove_node(self) -> None:
        """Retire un nœud hidden et toutes ses connexions entrantes/sortantes."""
        hidden = self.hidden_ids
        if not hidden:
            return

        rng = self._rng
        node_id = rng.choice(hidden)
        del self.nodes[node_id]

        # Supprimer toutes les connexions impliquant ce nœud
        keys_to_remove = [k for k in self.connections if node_id in k]
        for k in keys_to_remove:
            del self.connections[k]

    def _mutate_toggle_connections(self) -> None:
        """Active ou désactive une connexion sans la supprimer (CDC §2.2)."""
        rng = self._rng
        for conn in self.connections.values():
            if rng.random() < 0.02:  # 2 % par connexion
                conn.enabled = not conn.enabled

    # ── Vérification de cycle (DFS) ──────────────────────────────────

    def _would_create_cycle(self, from_id: int, to_id: int) -> bool:
        """DFS depuis to_id pour vérifier si on peut atteindre from_id.
        Si oui, ajouter from_id→to_id créerait un cycle."""
        visited: set[int] = set()
        stack = [to_id]

        # Construire la liste d'adjacence des connexions enabled
        adj: dict[int, list[int]] = {nid: [] for nid in self.nodes}
        for c in self.connections.values():
            if c.enabled:
                adj.setdefault(c.in_node_id, []).append(c.out_node_id)

        while stack:
            current = stack.pop()
            if current == from_id:
                return True
            if current in visited:
                continue
            visited.add(current)
            for neighbor in adj.get(current, []):
                stack.append(neighbor)

        return False

    # ══════════════════════════════════════════════════════════════════
    #  SÉRIALISATION JSON  (CDC §7.2)
    # ══════════════════════════════════════════════════════════════════

    def to_dict(self) -> dict[str, Any]:
        return {
            "num_inputs": self.num_inputs,
            "num_outputs": self.num_outputs,
            "next_hidden_id": self._next_hidden_id,
            "ray_range": self.ray_range,
            "nodes": [
                {"id": n.id, "type": n.type.value, "activation": n.activation}
                for n in self.nodes.values()
            ],
            "connections": [
                {
                    "in": c.in_node_id,
                    "out": c.out_node_id,
                    "weight": c.weight,
                    "enabled": c.enabled,
                    "innovation_id": c.innovation_id,
                }
                for c in self.connections.values()
            ],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Genome:
        g = cls.__new__(Genome)
        g.num_inputs = data["num_inputs"]
        g.num_outputs = data["num_outputs"]
        g._next_hidden_id = data.get("next_hidden_id", g.num_inputs + g.num_outputs)
        g._rng = random.Random()  # RNG par défaut au chargement

        g.ray_range = data.get("ray_range", 150.0)

        g.nodes = {}
        for nd in data["nodes"]:
            g.nodes[nd["id"]] = NodeGene(
                id=nd["id"],
                type=NodeType(nd["type"]),
                activation=nd.get("activation", "tanh"),
            )

        g.connections = {}
        for cd in data["connections"]:
            key = (cd["in"], cd["out"])
            g.connections[key] = ConnectionGene(
                in_node_id=cd["in"],
                out_node_id=cd["out"],
                weight=cd["weight"],
                enabled=cd["enabled"],
                innovation_id=cd.get("innovation_id", 0),
            )

        # Synchroniser le compteur d'innovation
        if g.connections:
            max_inn = max(c.innovation_id for c in g.connections.values())
            ic = InnovationCounter()
            if max_inn >= ic.current:
                ic._value = max_inn

        return g

    @classmethod
    def from_json(cls, json_str: str) -> Genome:
        return cls.from_dict(json.loads(json_str))