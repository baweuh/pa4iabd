"""
src/simulation.py — Boucle principale fixed timestep, population, métriques,
CSV logging, sauvegarde meilleur génome. CDC §6 + §7.
"""

from __future__ import annotations

import csv
import math
import os
import random
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from .agent import Agent
from .config import SimConfig
from .environment import Environment
from .genome import Genome, InnovationCounter


class Simulation:
    """
    Boucle de simulation ALife — neuroévolution continue.
    CDC §6 : Fixed timestep, ordre d'exécution par tick.
    CDC §7 : Métriques, CSV logging, meilleur génome.
    """

    def __init__(self, cfg: SimConfig, output_dir: str = "output") -> None:
        self.cfg = cfg
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # RNG — si seed est None, on tire une graine aléatoire (basée sur
        # l'entropie système) pour garantir une expérimentation différente
        # à chaque démarrage. La graine utilisée est conservée dans
        # self.actual_seed pour logging / reproductibilité.
        configured_seed = cfg.simulation.seed
        if configured_seed is None:
            # random.Random() sans argument utilise os.urandom / time — non déterministe
            seed_rng = random.Random()
            self.actual_seed = seed_rng.randrange(0, 2**31 - 1)
        else:
            self.actual_seed = int(configured_seed)
        self.rng = random.Random(self.actual_seed)

        # Afficher la graine utilisée pour permettre la reproduction d'un run
        print(f"[Simulation] Graine RNG utilisée : {self.actual_seed}")
        print(f"[Simulation] Pour reproduire ce run : ajoutez ?seed={self.actual_seed} à l'URL,")
        print(f"[Simulation] ou lancez avec --seed {self.actual_seed} / ALIFE_SEED={self.actual_seed}")

        # Réinitialiser le compteur d'innovation global
        InnovationCounter().reset()

        # Nombre d'inputs du réseau : 33 (CDC §5.5)
        self.num_inputs = cfg.agents.num_rays * 2 + 1  # 16*2 + 1 = 33
        self.num_outputs = 2  # vx, vy

        # Environnement
        self.env = Environment(cfg.environment, self.rng)

        # Population
        self.agents: list[Agent] = []
        self._bootstrap_population()

        # État de la simulation
        self.current_tick = 0
        self.total_reproductions = 0
        self.running = True

        # Métriques
        self.record_apples = 0
        self.best_agent: Agent | None = None
        self.dead_lifespans: list[int] = []  # pour avg_lifespan

        # CSV logging
        self._csv_path = self.output_dir / "metrics.csv"
        self._csv_file = None
        self._csv_writer = None
        self._init_csv()

        # Répertoire pour les génomes
        self.genome_dir = self.output_dir / "genomes"
        self.genome_dir.mkdir(parents=True, exist_ok=True)

    # ══════════════════════════════════════════════════════════════════
    #  INITIALISATION
    # ══════════════════════════════════════════════════════════════════

    def _bootstrap_population(self) -> None:
        """Crée la population initiale répartie dans la zone safe.
        CDC §5.1 : Spawn au centre de l'environnement — loin des murs pour le cold start.
        On étale les agents sur un cercle autour du centre pour éviter
        qu'ils se disputent les mêmes pommes au démarrage.
        """
        cfg_a = self.cfg.agents
        center_x = self.env.width / 2
        center_y = self.env.height / 2
        spread = min(self.env.safe_max_x, self.env.safe_max_y) / 3

        for _ in range(cfg_a.initial_population):
            genome = Genome(self.num_inputs, self.num_outputs, self.rng)
            # Répartir sur un cercle de rayon ~spread autour du centre
            angle = self.rng.uniform(0, 2 * math.pi)
            dist = self.rng.uniform(0, spread)
            x = center_x + dist * math.cos(angle)
            y = center_y + dist * math.sin(angle)
            x, y = self.env.clamp_position(x, y, cfg_a.agent_radius)

            agent = Agent(
                genome=genome,
                x=x,
                y=y,
                energy=cfg_a.bootstrap_initial_energy,
                cfg_agents=cfg_a,
                cfg_mutations=self.cfg.mutations,
                rng=self.rng,
                is_bootstrap=True,
            )
            self.agents.append(agent)

        # Focus initial sur le premier agent
        if self.agents:
            self.best_agent = self.agents[0]

    def _init_csv(self) -> None:
        """Initialise le fichier CSV avec les en-têtes (CDC §7.1)."""
        self._csv_file = open(self._csv_path, "w", newline="", encoding="utf-8")
        self._csv_writer = csv.writer(self._csv_file)
        self._csv_writer.writerow([
            "tick", "population", "food_available", "record_apples",
            "avg_lifespan", "total_reproductions", "avg_network_size",
        ])
        self._csv_file.flush()

    # ══════════════════════════════════════════════════════════════════
    #  BOUCLE PRINCIPALE  (CDC §6.2)
    # ══════════════════════════════════════════════════════════════════

    def step(self) -> bool:
        """
        Un tick de simulation complet. Retourne False si la simulation doit s'arrêter.
        Ordre d'exécution par tick (CDC §6.2) :
        1. Mise à jour des positions (vecteurs vitesse × inputs NN)
        2. Calcul des raycasts pour tous les agents
        3. Forward pass NN → nouveaux (vx, vy)
        4. Détection de contact pommes → énergie + food_energy
        5. Application drain énergétique (base + zone pénalité)
        6. Vérification reproduction (énergie ≥ threshold → créer enfant)
        7. Vérification mort (énergie ≤ 0 ou age ≥ max_lifespan → supprimer)
        8. Respawn pommes manquantes si délai écoulé
        9. Mise à jour métriques + logging CSV (tous les log_interval ticks)
        """
        if not self.running:
            return False

        # ── Étape 2+3 : Raycasts + forward pass ──
        for agent in self.agents:
            if not agent.alive:
                continue
            inputs = agent.compute_raycasts(self.env)
            agent.think(inputs)

        # ── Étape 1 : Mise à jour des positions ──
        for agent in self.agents:
            if not agent.alive:
                continue
            agent.move(self.env)
            agent.tick()

        # ── Étape 4 : Détection de contact pommes ──
        self._check_food_collision()

        # ── Étape 5 : Drain énergétique ──
        for agent in self.agents:
            if not agent.alive:
                continue
            agent.apply_energy_drain(self.env)

        # ── Étape 6 : Reproduction ──
        self._check_reproduction()

        # ── Étape 7 : Mort ──
        self._check_death()

        # ── Étape 8 : Respawn pommes ──
        self.env.respawn_apples(self.current_tick)

        # ── Étape 9 : Métriques + logging ──
        self.current_tick += 1
        if self.current_tick % self.cfg.simulation.log_interval == 0:
            self._log_metrics()

        # ── Vérification extinction ──
        if len(self.agents) == 0:
            self._handle_extinction()
            return False

        return True

    # ══════════════════════════════════════════════════════════════════
    #  SOUS-ÉTAPES
    # ══════════════════════════════════════════════════════════════════

    def _check_food_collision(self) -> None:
        """Détecte le contact agent-pomme (hitbox circulaire). Vectorisé NumPy."""
        if not self.agents:
            return

        agent_radius = self.cfg.agents.agent_radius
        food_radius = self.cfg.agents.food_radius
        eat_dist_sq = (agent_radius + food_radius) ** 2

        # Préparer les positions des pommes actives
        active_indices = [i for i, a in enumerate(self.env.apples) if a.respawn_at_tick < 0]
        if not active_indices:
            return

        food_pos = np.array([[self.env.apples[i].x, self.env.apples[i].y] for i in active_indices])

        for agent in self.agents:
            if not agent.alive:
                continue
            # Distance vectorisée agent → toutes les pommes actives
            dx = agent.x - food_pos[:, 0]
            dy = agent.y - food_pos[:, 1]
            dists_sq = dx * dx + dy * dy

            closest = np.argmin(dists_sq)
            if dists_sq[closest] <= eat_dist_sq:
                real_idx = active_indices[closest]
                agent.eat(self.cfg.environment.food_energy)
                self.env.eat_apple(real_idx, self.current_tick)
                self._update_best_agent(agent)
                # Retirer la pomme mangée des candidates pour les agents suivants
                food_pos = np.delete(food_pos, closest, axis=0)
                active_indices.pop(closest)
                if not active_indices:
                    break

    def _check_reproduction(self) -> None:
        """Vérifie la reproduction pour chaque agent (CDC §2.3)."""
        new_agents: list[Agent] = []
        for agent in self.agents:
            if not agent.alive:
                continue
            if agent.can_reproduce():
                child = agent.reproduce(self.env)
                new_agents.append(child)
                self.total_reproductions += 1
        self.agents.extend(new_agents)

    def _check_death(self) -> None:
        """Supprime les agents morts et enregistre leur lifespan."""
        survivors: list[Agent] = []
        for agent in self.agents:
            if agent.is_dead():
                self.dead_lifespans.append(agent.age)
            else:
                survivors.append(agent)
        self.agents = survivors

        # Si le meilleur agent est mort, sélectionner le meilleur vivant
        if self.best_agent is None or not self.best_agent.alive:
            if self.agents:
                self.best_agent = max(self.agents, key=lambda a: a.food_eaten)

    def _update_best_agent(self, agent: Agent) -> None:
        """Met à jour le meilleur agent si un nouveau record est battu (CDC §7.2).
        Critère : record du nombre de pommes mangées cumulatif sur une vie.
        Sauvegarde automatique du génome JSON."""
        if agent.food_eaten > self.record_apples:
            self.record_apples = agent.food_eaten
            self.best_agent = agent
            # Sauvegarder le génome immédiatement
            filename = f"best_genome_tick_{self.current_tick}_apples_{agent.food_eaten}.json"
            filepath = self.genome_dir / filename
            filepath.write_text(agent.genome.to_json(), encoding="utf-8")

    # ══════════════════════════════════════════════════════════════════
    #  MÉTRIQUES  (CDC §7.1)
    # ══════════════════════════════════════════════════════════════════

    def _log_metrics(self) -> None:
        """Écrit une ligne CSV (CDC §7.1)."""
        # avg_lifespan : durée de vie moyenne des agents morts depuis dernier log
        if self.dead_lifespans:
            avg_lifespan = sum(self.dead_lifespans) / len(self.dead_lifespans)
            self.dead_lifespans.clear()
        else:
            avg_lifespan = 0.0

        # avg_network_size : taille moyenne des réseaux (connexions actives)
        if self.agents:
            avg_net_size = sum(a.network.network_size for a in self.agents) / len(self.agents)
        else:
            avg_net_size = 0.0

        if self._csv_writer is not None:
            self._csv_writer.writerow([
                self.current_tick,
                len(self.agents),
                self.env.food_available,
                self.record_apples,
                round(avg_lifespan, 2),
                self.total_reproductions,
                round(avg_net_size, 2),
            ])
            self._csv_file.flush()

    # ══════════════════════════════════════════════════════════════════
    #  FIN DE SIMULATION  (CDC §7.3)
    # ══════════════════════════════════════════════════════════════════

    def _handle_extinction(self) -> None:
        """Arrêt propre sur extinction : sauvegarde CSV finale + message (CDC §7.3)."""
        self.running = False
        # Dernière ligne de métriques
        self._log_metrics()
        timestamp = datetime.now(timezone.utc).isoformat()
        msg = (
            f"[{timestamp}] EXTINCTION — Population = 0 au tick {self.current_tick}. "
            f"Record pommes : {self.record_apples}. Graine : {self.actual_seed}."
        )
        print(msg)
        # Écrire dans un fichier log
        log_path = self.output_dir / "simulation.log"
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    def shutdown(self) -> None:
        """Arrêt propre (Ctrl+C ou autre interruption)."""
        self.running = False
        if self._csv_file is not None:
            self._csv_file.close()
        timestamp = datetime.now(timezone.utc).isoformat()
        msg = (
            f"[{timestamp}] INTERRUPTION MANUELLE — Tick {self.current_tick}. "
            f"Record pommes : {self.record_apples}. Graine : {self.actual_seed}."
        )
        print(msg)
        log_path = self.output_dir / "simulation.log"
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(msg + "\n")