# Worklog — ALife NEAT Project

---
Task ID: 1
Agent: main
Task: Fusion poc2.2 — Étapes 8, 5, 3, 2

Work Log:
- Étape 8 : Ajouté `weight_max: 5.0` dans MutationsConfig + clamp dans `_mutateWeights()`
- Étape 5 : Encodage 3-canaux (dist + apple_flag + wall_flag) → 49 inputs (vs 33). Outputs linéaires dans network.ts, tanh appliqué dans agent.think()
- Étape 3 : Cap population (max_population: 150), sélection par énergie au plafond, elite injection du meilleur génome
- Étape 2 : Spéciation NEAT (compatibility distance), métriques : max_generation, species_count, mean_genetic_distance, mean_forage_rate, max_forage_rate. Agent.generation pour suivi des lignées.
- Ajouté PopulationConfig, SpeciationConfig dans config.ts
- HUD mis à jour avec section "Évolution" (violet) affichant les 5 nouvelles métriques
- Build Next.js OK (0 erreurs)

Stage Summary:
- 4 étapes de fusion poc2.2 terminées en un seul pass
- Fichiers modifiés : config.ts, genome.ts, network.ts, agent.ts, simulation.ts, page.tsx
- Build passes. Simulation passe de 33→49 inputs, ajoute sélection au plafond + spéciation + elite.

---
Task ID: 2
Agent: main
Task: Fusion poc2.2 — Étapes 6, 1, 4, 7

Work Log:
- Étape 6 : Ajouté toJSON()/fromJSON() à Genome (sérialisation complète incluant ray_range)
- Étape 1 : Créé config/default.yaml (source de vérité externe), ajouté loader.ts (loadConfigFromYaml + configFromDict), ConfigError, validateSimConfig() avec validation locale + cross-section invariants. Ajouté LoggingConfig. Installé js-yaml.
- Étape 4 : Modèle égocentrique — Agent.heading (rad, [0,2π)), outputs = (speed, turn_delta). computeRaycasts() centré sur heading (ray 0 = avant). think() convertit en (vx, vy) monde. Child hérite du heading du parent. max_turn_rate: 0.2 rad/tick. Renderer utilise heading pour la direction.
- Étape 7 : 69 tests vitest portés du POC pytest (config: 12, genome: 13, network: 7, agent: 20, environment: 9, speciation: 8). Installé vitest + vitest.config.ts.
- Bug fix network.ts : forward pass refait en ordre topologique (applique activation hidden AVANT propagation aux outputs). L'ancien code appliquait les activations après toutes les propagations → les outputs recevaient les valeurs pré-activation.
- Build Next.js OK, 69/69 tests passent.

Stage Summary:
- 4 étapes de fusion terminées (6, 1, 4, 7)
- Fichiers créés : config/default.yaml, src/lib/alife/loader.ts, vitest.config.ts, __tests__/alife/*.test.ts (6 fichiers)
- Fichiers modifiés : config.ts, genome.ts, network.ts, agent.ts, page.tsx
- Total fusion poc2.2 : 8/8 étapes complètes

---
Task ID: 3
Agent: main
Task: Vérification des étapes de fusion + implémentation manquante (1, 4, 6, 7)

Work Log:
- Audit complet des 8 étapes vs le POC Python poc2.2 (36 tests de vérification écrits)
- Bug trouvé et corrigé : bootstrap créait 30 génomes avec innovation_ids différents → 30 "espèces" fictives. Fix : cloner le template + randomiser les poids uniquement
- Étape 4 (fix) : clamp bas manquant dans l'énergie normalisée (max(0, ...))
- Étape 6 (complétion) : CSV logging en mémoire (13 colonnes dont species_count, forage_rate) + best genome JSON snapshots via getCsvContent()/getBestGenomeSnapshots()
- Étape 1 (complétion) : Tests manquants ajoutés (missing_key, invalid_yaml, from_dict values, inputs consistency)
- Étape 7 (complétion) : 50 tests supplémentaires portés (config-missing: 7, agent-missing: 10, genome-missing: 9, environment-missing: 9, simulation-missing: 15)
- Fichiers créés/modifiés : simulation.ts (CSV + genome archive), agent.ts (clamp fix), 5 nouveaux fichiers de test
- Résultat final : 155/155 tests passent, 12 fichiers de test

Stage Summary:
- Toutes les 8 étapes de fusion sont implémentées ET vérifiées
- 155 tests vitest passent (vs 69 avant + 86 nouveaux)
- CSV logging fonctionnel (header 13 colonnes, interval configurable, accessible via getCsvContent())
- Best genome archivé en JSON à chaque record battu
- Bootstrap NEAT canonique (1 espèce initiale)