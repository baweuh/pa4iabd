// ═══════════════════════════════════════════════════════════
//  agent.ts — Agent: raycasts égocentriques, heading, énergie
//  CDC v5 §4 : perception, cycle de vie, énergie
//
//  Conformité CDC :
//  - Pas de fitness explicite (CDC §1.1 : sélection émergente)
//  - Pas de cooldown reproduction (CDC §2.3)
//  - Reproduction = seuil d'énergie atteint → clone + mutate
//  - Ray_range est un trait évolutif (écart positif, remarque prof)
//
//  poc2.2 step 4 : modèle égocentrique
//  - output[0] × max_speed = vitesse signée (avancer/reculer)
//  - output[1] × max_turn_rate = delta heading (rad/tick)
//  - Raycasts centrés sur le heading (ray 0 = avant)
//
//  Vision dynamique (plasticité phénotypique) :
//  - Manger booste la portée visuelle (×1.5)
//  - Ne pas manger la réduit progressivement (jusqu'à ×0.4)
//  - Crée un cercle vertueux : manger → voir plus → manger plus
// ═══════════════════════════════════════════════════════════

import { Genome, SeededRNG } from './genome';
import { NeuralNetwork } from './network';
import { Environment } from './environment';
import type { AgentsConfig, MutationsConfig } from './config';

export interface RayHit {
  x: number;
  y: number;
  kind: number; // 0 = nothing, 0.5 = food, 1.0 = wall
}

export class Agent {
  genome: Genome;
  network: NeuralNetwork;
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  energy: number;
  cfg: AgentsConfig;
  cfgMut: MutationsConfig;
  rng: SeededRNG;

  age = 0;
  alive = true;
  isBootstrap: boolean;

  foodEaten = 0;
  childrenCount = 0;
  generation = 0;            // Profondeur de lignée (poc2.2 — observable évolutif)

  // CDC §2.3 : pas de cooldown — la performance est récompensée directement
  // lastReproductionTick conservé uniquement pour la méthode reproduce()
  lastReproductionTick = -999;

  // poc2.2 step 4 : heading égocentrique
  heading: number;  // radians [0, 2π)

  rays: RayHit[] = [];
  inputSize: number;

  // ── Vision dynamique (plasticité phénotypique) ──
  // Manger booste la vision, ne pas manger la réduit.
  // Crée un cercle vertueux : manger → voir plus → manger plus.
  ticksSinceLastMeal = 0;
  currentVisionMultiplier = 1.0;

  // ── Cache pour le renderer (poc2.2 pattern) ──
  // Le renderer lit ce cache au lieu de recalculer les raycasts.
  lastSenses: number[] = [];

  constructor(
    genome: Genome,
    x: number,
    y: number,
    energy: number,
    cfgAgents: AgentsConfig,
    cfgMutations: MutationsConfig,
    rng: SeededRNG,
    isBootstrap: boolean,
    heading?: number,
  ) {
    this.genome = genome;
    this.network = new NeuralNetwork(genome);
    this.x = x;
    this.y = y;
    this.energy = energy;
    this.cfg = cfgAgents;
    this.cfgMut = cfgMutations;
    this.rng = rng;
    this.isBootstrap = isBootstrap;
    // poc2.2 : 3 canaux par rayon (dist + apple_flag + wall_flag) + 1 énergie
    this.inputSize = cfgAgents.num_rays * 3 + 1;
    // poc2.2 step 4 : heading aléatoire au bootstrap, hérité à la reproduction
    this.heading = heading ?? rng.uniform(0, 2 * Math.PI);
  }

  // ── Vision dynamique ──────────────────────────────────

  /**
   * Calcule le multiplicateur de vision basé sur le temps depuis le dernier repas.
   * - Juste après avoir mangé : ×1.5 (vision étendue)
   * - Après vision_decay_ticks sans manger : ×0.4 (vision réduite)
   * - Interpolation linéaire entre les deux.
   */
  get effectiveRayRange(): number {
    const boost = this.cfg.vision_boost_max;
    const min = this.cfg.vision_min_multiplier;
    const decay = this.cfg.vision_decay_ticks;

    if (this.ticksSinceLastMeal === 0) {
      this.currentVisionMultiplier = boost;
    } else if (this.ticksSinceLastMeal >= decay) {
      this.currentVisionMultiplier = min;
    } else {
      // Interpolation linéaire : boost → min sur `decay` ticks
      const t = this.ticksSinceLastMeal / decay;
      this.currentVisionMultiplier = boost - (boost - min) * t;
    }

    return Math.max(20, Math.min(
      this.genome.ray_range * this.currentVisionMultiplier,
      this.cfg.ray_max_range,
    ));
  }

  // ── Reproduction (CDC §2.3 — asexuée, pas de cooldown) ──

  /**
   * CDC §2.3 : Un agent se reproduit dès que son énergie atteint le seuil.
   * Pas de cooldown — la performance est récompensée directement.
   */
  canReproduce(): boolean {
    return this.energy >= this.cfg.reproduction_threshold;
  }

  reproduce(env: Environment, currentTick: number): Agent {
    // CDC §2.3 étape 1 : énergie parent ≥ threshold
    // CDC §2.3 étape 2 : deep copy + mutations
    const childGenome = this.genome.deepCopy();
    childGenome.mutate(this.cfgMut);

    // CDC §2.3 étape 3 : énergie post-repro
    // Parent : énergie → parent_energy_after_repro (1.0)
    this.energy = this.cfg.parent_energy_after_repro;
    this.lastReproductionTick = currentTick;
    this.childrenCount++;

    // CDC §2.3 étape 4 : spawn enfant (rayon 50-100 px du parent)
    const [childX, childY] = this._findSpawnPosition(env);

    // poc2.2 step 4 : enfant hérite du heading du parent
    return new Agent(
      childGenome, childX, childY,
      this.cfg.child_initial_energy, // CDC : 2.0
      this.cfg, this.cfgMut, this.rng, false,
      this.heading,
    );
  }

  // Override constructor to pass generation
  overrideConstructor(generation: number): void {
    this.generation = generation;
  }

  // ── Perception (CDC §4.4 — 16 raycasts égocentriques) ──
  // poc2.2 step 4 : raycasts centrés sur le heading
  //   Ray 0 = direction du heading (avant)
  //   Les rayons couvrent 360° centrés sur heading
  //
  // poc2.2 : encodage 3-canaux par rayon
  //   [0..15]  = distances normalisées [0→1]
  //   [16..31] = apple flags (0.0 ou 1.0)
  //   [32..47] = wall flags  (0.0 ou 1.0)
  //   [48]     = énergie normalisée
  // → 49 inputs

  computeRaycasts(env: Environment): number[] {
    const numRays = this.cfg.num_rays;
    const rayRange = this.effectiveRayRange; // ← vision dynamique
    const foodRadius = this.cfg.food_radius;
    const inputs = new Float64Array(this.inputSize);
    this.rays = [];
    const fovStep = (2 * Math.PI) / numRays;

    const maxDistSq = (rayRange + foodRadius + 5) ** 2;
    const activeApples = env.apples.filter(
      a => a.respawn_at_tick < 0 && (a.x - this.x) ** 2 + (a.y - this.y) ** 2 <= maxDistSq,
    );

    for (let i = 0; i < numRays; i++) {
      // poc2.2 step 4 : angle égocentrique centré sur heading
      const angle = this.heading + i * fovStep;
      const dx = Math.cos(angle);
      const dy = Math.sin(angle);

      // Mur intersection (CDC §4.4 : first-hit)
      let wallT = rayRange + 1;
      if (dx < -1e-9) { const t = -this.x / dx; if (t > 0 && t < wallT) wallT = t; }
      if (dx > 1e-9) { const t = (env.width - this.x) / dx; if (t > 0 && t < wallT) wallT = t; }
      if (dy < -1e-9) { const t = -this.y / dy; if (t > 0 && t < wallT) wallT = t; }
      if (dy > 1e-9) { const t = (env.height - this.y) / dy; if (t > 0 && t < wallT) wallT = t; }

      // Nourriture intersection (CDC §4.4 : first-hit, occlusion)
      let foodT = rayRange + 1;
      let hitFood = false;
      const detectRSq = (foodRadius + 10) ** 2;

      for (const apple of activeApples) {
        const vfx = apple.x - this.x;
        const vfy = apple.y - this.y;
        const proj = vfx * dx + vfy * dy;
        if (proj <= 0 || proj >= Math.min(wallT, foodT)) continue;
        const px = this.x + proj * dx;
        const py = this.y + proj * dy;
        if ((px - apple.x) ** 2 + (py - apple.y) ** 2 <= detectRSq) {
          foodT = proj;
          hitFood = true;
        }
      }

      // poc2.2 : encodage 3-canaux
      const hitWall = wallT <= rayRange;
      const closestT = (hitFood && foodT < wallT) ? foodT : (hitWall ? wallT : rayRange);

      inputs[i] = closestT / rayRange;                    // distance
      inputs[numRays + i] = (hitFood && foodT < wallT) ? 1.0 : 0.0;  // apple flag
      inputs[numRays * 2 + i] = (hitWall && !(hitFood && foodT < wallT)) ? 1.0 : 0.0; // wall flag

      // Ray pour le renderer
      const kind = (hitFood && foodT < wallT) ? 0.5 : (hitWall ? 1.0 : 0.0);
      this.rays.push({ x: this.x + closestT * dx, y: this.y + closestT * dy, kind });
    }

    // Dernier input = énergie normalisée (clampé dans [0, 1])
    inputs[numRays * 3] = Math.max(0, Math.min(this.energy / this.cfg.max_energy, 1.0));

    // Cache pour le renderer (poc2.2 pattern)
    this.lastSenses = [...inputs];

    return this.lastSenses;
  }

  // ── Décision et mouvement (poc2.2 step 4 : modèle égocentrique) ──
  // output[0] (tanh ∈ (-1,1)) × max_speed = vitesse signée (avant/arrière)
  // output[1] (tanh ∈ (-1,1)) × max_turn_rate = delta heading (rad/tick)
  // → conversion en (vx, vy) monde-frame

  think(inputs: number[]): void {
    const outputs = this.network.activate(inputs, this.rng);

    // ── Exploration noise (anti-spinning) ──
    // Bruit gaussien sur les outputs du réseau.
    // Quand aucun rayon ne voit de nourriture, les inputs sont identiques
    // partout → le réseau sort une réponse fixe → cercle parfait.
    // Le bruit casse ce déterminisme : l'agent dévie aléatoirement et
    // finit par tomber sur de la nourriture, créant une pression de
    // sélection pour de vraies stratégies de recherche.
    // Le bruit est réduit quand la nourriture est détectée (inputs[16..31])
    // pour ne pas perturber la navigation ciblée.
    const foodDetection = inputs.slice(
      this.cfg.num_rays,
      this.cfg.num_rays * 2,
    ).reduce((a, b) => a + b, 0);
    const noFoodRatio = 1 - foodDetection / this.cfg.num_rays;
    const noiseSigma = 0.12 * noFoodRatio; // 0.12 quand pas de nourriture, ~0 quand nourriture
    const noisySpeed = outputs[0] + this.rng.gauss(0, noiseSigma);
    const noisyTurn = outputs[1] + this.rng.gauss(0, noiseSigma);

    // Modèle égocentrique (poc2.2 step 4)
    const rawSpeed = Math.tanh(noisySpeed) * this.cfg.max_speed;
    const rawTurnDelta = Math.tanh(noisyTurn) * this.cfg.max_turn_rate;

    // Mise à jour heading (modulo 2π)
    this.heading = (this.heading + rawTurnDelta) % (2 * Math.PI);
    if (this.heading < 0) this.heading += 2 * Math.PI;

    // Conversion heading + vitesse → (vx, vy) en coordonnées monde
    this.vx = rawSpeed * Math.cos(this.heading);
    this.vy = rawSpeed * Math.sin(this.heading);
  }

  move(env: Environment): void {
    // vx, vy déjà calculés par think() — pas de re-normalisation needed
    // car tanh × max_speed bornent déjà la vitesse
    const [newX, newY] = env.clampPosition(this.x + this.vx, this.y + this.vy, this.cfg.agent_radius);
    this.x = newX;
    this.y = newY;
  }

  // ── Énergie (CDC §4.3) ──

  applyEnergyDrain(env: Environment): void {
    // Drain vision (plus de rayons = plus coûteux)
    const visionCost = this.genome.ray_range / 150.0;
    let drain = this.cfg.base_drain_rate * visionCost;
    // Zone pénalité murale (CDC §3.2)
    drain += env.wallPenaltyDrain(this.x, this.y);
    this.energy -= drain;

    // Incrémenter le compteur de faim (vision dynamique)
    this.ticksSinceLastMeal++;
  }

  eat(foodEnergy: number): void {
    // Cap d'énergie : un agent ne peut pas dépasser max_energy
    this.energy = Math.min(this.energy + foodEnergy, this.cfg.max_energy);
    this.foodEaten++;

    // Vision dynamique : reset le compteur de faim → boost immédiat
    this.ticksSinceLastMeal = 0;
  }

  // ── Cycle de vie (CDC §4.2) ──

  isDead(): boolean {
    if (this.energy <= 0) return true;     // Mort par famine
    if (this.age >= this.cfg.max_lifespan) return true; // Mort par vieillesse
    return false;
  }

  isDying(): boolean {
    return this.age >= this.cfg.max_lifespan - this.cfg.lifespan_warning_ticks;
  }

  tick(): void {
    this.age++;
  }

  // ── Spawn (CDC §2.3 étape 4) ──

  private _findSpawnPosition(env: Environment): [number, number] {
    const spawnRadius = this.cfg.spawn_radius_child;
    for (let attempt = 0; attempt < 50; attempt++) {
      const angle = this.rng.uniform(0, 2 * Math.PI);
      const dist = this.rng.uniform(50, spawnRadius);
      const childX = this.x + dist * Math.cos(angle);
      const childY = this.y + dist * Math.sin(angle);
      if (env.isValidSpawn(childX, childY, this.cfg.agent_radius)) {
        return env.clampPosition(childX, childY, this.cfg.agent_radius);
      }
    }
    return [this.x, this.y];
  }
}