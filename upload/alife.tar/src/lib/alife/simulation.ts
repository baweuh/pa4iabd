// ═══════════════════════════════════════════════════════════
//  simulation.ts — Boucle principale, sélection émergente
//  CDC v5 §5–§7 + fusion poc2.2
//
//  Conformité CDC :
//  - Reproduction asexuée uniquement (clone + mutate) — §2.3
//  - Pas de crossover, fitness explicite — §11 hors scope
//  - Pas de cooldown reproduction — §2.3
//  - Ordre d'exécution par tick conforme à CDC §6.2
//
//  Fusion poc2.2 :
//  - Sélection au plafond par priorité d'énergie
//  - Elite injection (clone non-muté du meilleur)
//  - Spéciation observatrice (NEAT compatibility distance)
//  - Métriques : génération, espèces, diversité, forage rate
// ═══════════════════════════════════════════════════════════

import { Genome, InnovationCounter, SeededRNG } from './genome';
import { Agent } from './agent';
import { Environment } from './environment';
import type { SimConfig } from './config';

// ── État exposé au renderer ────────────────────────────────

export interface SimState {
  currentTick: number;
  population: number;
  foodAvailable: number;
  recordApples: number;
  totalReproductions: number;
  avgEnergy: number;
  avgNetSize: number;
  avgLifespan: number;
  bestAgentFood: number;
  bestAgentEnergy: number;
  bestAgentAge: number;
  bestAgentChildren: number;
  bestAgentNetSize: number;
  running: boolean;
  seed: number;
  ticksPerFrame: number;
  paused: boolean;
  // Métriques poc2.2
  maxGeneration: number;
  speciesCount: number;
  meanGeneticDistance: number;
  meanForageRate: number;
  maxForageRate: number;
}

// ── Simulation ───────────────────────────────────────────

const CSV_HEADER = [
  'tick', 'population', 'food_available', 'record_apples',
  'avg_lifespan', 'total_reproductions', 'avg_network_size',
  'max_generation', 'mean_generation', 'species_count',
  'mean_genetic_distance', 'mean_forage_rate', 'max_forage_rate',
].join(',');

export class Simulation {
  cfg: SimConfig;
  rng: SeededRNG;
  actualSeed: number;

  numInputs: number;
  numOutputs: number;
  env: Environment;
  agents: Agent[] = [];

  currentTick = 0;
  totalReproductions = 0;
  running = true;

  recordApples = 0;
  bestAgent: Agent | null = null;

  // Pour métrique avg_lifespan (CDC §7.1)
  private deadLifespans: number[] = [];

  // Exposé pour contrôles
  ticksPerFrame = 1;
  paused = false;

  // ── CSV logging (poc2.2 — step 6) ──
  private _csvLines: string[] = [CSV_HEADER];
  private _logInterval: number;
  private _lastLogTick = 0;

  // ── Best genome archive (poc2.2 — step 6) ──
  private _bestAgentCounter = 0;
  private _bestGenomes: string[] = [];  // JSON snapshots

  constructor(cfg: SimConfig, seed?: number) {
    this.cfg = cfg;
    this.actualSeed = seed ?? cfg.simulation.seed;
    this.rng = new SeededRNG(this.actualSeed);

    InnovationCounter().reset();

    // poc2.2 : 49 inputs (16 rays × 3 + 1 énergie)
    this.numInputs = cfg.agents.num_rays * 3 + 1;
    this.numOutputs = 2; // vx, vy

    this.env = new Environment(cfg.environment, this.rng);
    this._logInterval = cfg.logging?.log_interval_ticks ?? 100;
    this._bootstrapPopulation();
  }

  // ═══════════════════════════════════════════════════════════
  //  INITIALISATION (CDC §5.1)
  // ═══════════════════════════════════════════════════════════

  private _bootstrapPopulation(): void {
    const cfgA = this.cfg.agents;
    const centerX = this.env.width / 2;
    const centerY = this.env.height / 2;
    const spread = Math.min(this.env.safeMaxX, this.env.safeMaxY) / 3;

    // NEAT canonique : tous les génomes bootstrap partagent la même topologie
    // et les mêmes innovation_ids. Seuls les poids et ray_range diffèrent.
    // → la spéciation démarre à 1 espèce (distance = 0 entre clones topologiques)
    const template = new Genome(this.numInputs, this.numOutputs, this.rng);

    for (let i = 0; i < this.cfg.population.initial_population; i++) {
      // Clone du template pour partager les innovation_ids
      const genome = i === 0 ? template : template.deepCopy();
      // Randomiser les poids et ray_range pour diversité initiale
      if (i > 0) {
        for (const conn of genome.connections.values()) {
          conn.weight = this.rng.uniform(-1, 1);
        }
        genome.ray_range = this.rng.uniform(40, 150);
      }
      const angle = this.rng.uniform(0, 2 * Math.PI);
      const dist = this.rng.uniform(0, spread);
      let x = centerX + dist * Math.cos(angle);
      let y = centerY + dist * Math.sin(angle);
      [x, y] = this.env.clampPosition(x, y, cfgA.agent_radius);

      const agent = new Agent(
        genome, x, y, cfgA.bootstrap_initial_energy,
        cfgA, this.cfg.mutations, this.rng, true,
      );
      this.agents.push(agent);
    }

    if (this.agents.length > 0) this.bestAgent = this.agents[0];
  }

  // ═══════════════════════════════════════════════════════════
  //  BOUCLE PRINCIPALE — ordre CDC §6.2
  // ═══════════════════════════════════════════════════════════

  step(): boolean {
    if (!this.running) return false;

    // ── CDC §6.2 étape 1 : Mise à jour des positions ──
    for (const agent of this.agents) {
      if (!agent.alive) continue;
      agent.move(this.env);
    }

    // ── CDC §6.2 étape 2 : Calcul des raycasts ──
    // ── CDC §6.2 étape 3 : Forward pass NN → nouveaux (vx, vy) ──
    for (const agent of this.agents) {
      if (!agent.alive) continue;
      const inputs = agent.computeRaycasts(this.env);
      agent.think(inputs);
      agent.tick();
    }

    // ── CDC §6.2 étape 4 : Détection de contact pommes ──
    this._checkFoodCollision();

    // ── CDC §6.2 étape 5 : Application drain énergétique ──
    for (const agent of this.agents) {
      if (!agent.alive) continue;
      agent.applyEnergyDrain(this.env);
    }

    // ── CDC §6.2 étape 6 : Reproduction (avec sélection au plafond — poc2.2) ──
    this._checkReproduction();

    // ── CDC §6.2 étape 7 : Vérification mort ──
    this._checkDeath();

    // ── CDC §6.2 étape 8 : Respawn pommes ──
    this.env.respawnApples(this.currentTick);

    // ── CDC §6.2 étape 9 : Métriques ──
    this.currentTick++;

    // ── CSV logging (poc2.2 — step 6) ──
    if (this.currentTick - this._lastLogTick >= this._logInterval) {
      this._logRow();
      this._lastLogTick = this.currentTick;
    }

    // ── CDC §5.3 : extinction = arrêt propre, pas de respawn ──
    if (this.agents.length === 0) {
      this.running = false;
      return false;
    }

    return true;
  }

  // ═══════════════════════════════════════════════════════════
  //  SOUS-ÉTAPES
  // ═══════════════════════════════════════════════════════════

  private _checkFoodCollision(): void {
    if (this.agents.length === 0) return;

    const agentRadius = this.cfg.agents.agent_radius;
    const foodRadius = this.cfg.agents.food_radius;
    const eatDistSq = (agentRadius + foodRadius) ** 2;

    const activeIndices: number[] = [];
    for (let i = 0; i < this.env.apples.length; i++) {
      if (this.env.apples[i].respawn_at_tick < 0) activeIndices.push(i);
    }
    if (activeIndices.length === 0) return;

    for (const agent of this.agents) {
      if (!agent.alive) continue;

      let closestIdx = -1;
      let closestDistSq = Infinity;
      let closestActiveIdx = -1;

      for (let ai = 0; ai < activeIndices.length; ai++) {
        const appleIdx = activeIndices[ai];
        const apple = this.env.apples[appleIdx];
        const dx = agent.x - apple.x;
        const dy = agent.y - apple.y;
        const distSq = dx * dx + dy * dy;
        if (distSq < closestDistSq) {
          closestDistSq = distSq;
          closestIdx = appleIdx;
          closestActiveIdx = ai;
        }
      }

      if (closestIdx >= 0 && closestDistSq <= eatDistSq) {
        agent.eat(this.cfg.environment.food_energy);
        this.env.eatApple(closestIdx, this.currentTick);
        this._updateRecord(agent);
        activeIndices.splice(closestActiveIdx, 1);
        if (activeIndices.length === 0) break;
      }
    }
  }

  // ═══════════════════════════════════════════════════════════
  //  REPRODUCTION — CDC §2.3 + sélection au plafond (poc2.2)
  // ═══════════════════════════════════════════════════════════

  private _checkReproduction(): void {
    const maxPop = this.cfg.population.max_population;
    const survivors = this.agents.filter(a => a.alive);
    const slots = maxPop - survivors.length;
    if (slots <= 0) return;

    // poc2.2 : au plafond, les plus énergétiques se reproduisent d'abord
    // → pression de sélection fonctionnelle (pas FIFO)
    const eligible = survivors
      .filter(a => a.canReproduce())
      .sort((a, b) => b.energy - a.energy);

    const children: Agent[] = [];
    for (const agent of eligible) {
      while (agent.canReproduce() && children.length < slots) {
        const child = agent.reproduce(this.env, this.currentTick);
        child.generation = agent.generation + 1;
        children.push(child);
        this.totalReproductions++;
      }
      if (children.length >= slots) break;
    }

    this.agents.push(...children);
  }

  // ═══════════════════════════════════════════════════════════
  //  MORT — CDC §4.2
  // ═══════════════════════════════════════════════════════════

  private _checkDeath(): void {
    const survivors: Agent[] = [];
    for (const agent of this.agents) {
      if (agent.isDead()) {
        this.deadLifespans.push(agent.age);
      } else {
        survivors.push(agent);
      }
    }
    this.agents = survivors;

    if (!this.bestAgent || !this.bestAgent.alive) {
      if (this.agents.length > 0) {
        this.bestAgent = this.agents.reduce((b, a) => a.foodEaten > b.foodEaten ? a : b, this.agents[0]);
      }
    }
  }

  // ═══════════════════════════════════════════════════════════
  //  RECORD + ELITE INJECTION (poc2.2)
  // ═══════════════════════════════════════════════════════════

  private _updateRecord(agent: Agent): void {
    if (agent.foodEaten > this.recordApples) {
      this.recordApples = agent.foodEaten;
      this.bestAgent = agent;
      this._injectElite(agent.genome);
      this._saveBestGenome(agent.genome);
    }
  }

  /**
   * poc2.2 : Elite injection — clone non-muté du meilleur génome
   * si un slot est disponible. Garde le meilleur contrôleur dans
   * la population même si l'original meurt.
   */
  private _injectElite(genome: Genome): void {
    if (this.agents.length >= this.cfg.population.max_population) return;
    const eliteGenome = genome.deepCopy();
    const cfgA = this.cfg.agents;
    const [x, y] = this.env.clampPosition(
      this.rng.uniform(this.env.safeMin + 20, this.env.safeMaxX - 20),
      this.rng.uniform(this.env.safeMin + 20, this.env.safeMaxY - 20),
      cfgA.agent_radius,
    );
    const elite = new Agent(
      eliteGenome, x, y, cfgA.bootstrap_initial_energy,
      cfgA, this.cfg.mutations, this.rng, false,
    );
    this.agents.push(elite);
  }

  // ═══════════════════════════════════════════════════════════
  //  CSV LOGGING + BEST GENOME (poc2.2 — step 6)
  // ═══════════════════════════════════════════════════════════

  /** Récupère le contenu CSV accumulé (header + lignes). */
  getCsvContent(): string {
    return this._csvLines.join('\n');
  }

  /** Récupère les snapshots JSON des meilleurs génomes. */
  getBestGenomeSnapshots(): string[] {
    return [...this._bestGenomes];
  }

  private _logRow(): void {
    const genomes = this.agents.map(a => a.genome);
    const generations = this.agents.map(a => a.generation);
    const forageRates = this._forageRates();
    const avgLifespan = this.deadLifespans.length > 0
      ? this.deadLifespans.reduce((s, v) => s + v, 0) / this.deadLifespans.length : 0;
    const avgNetSize = this.agents.length > 0
      ? this.agents.reduce((s, a) => s + a.network.networkSize, 0) / this.agents.length : 0;
    const meanGen = generations.length > 0
      ? generations.reduce((s, v) => s + v, 0) / generations.length : 0;
    const speciesCount = this._countSpecies(genomes);
    const meanGenDist = genomes.length >= 2 ? this._meanPairwiseDistance(genomes) : 0;
    const meanFR = forageRates.length > 0
      ? forageRates.reduce((s, v) => s + v, 0) / forageRates.length : 0;
    const maxFR = forageRates.length > 0 ? Math.max(...forageRates) : 0;

    this._csvLines.push([
      this.currentTick,
      this.agents.length,
      this.env.foodAvailable,
      this.recordApples,
      avgLifespan.toFixed(6),
      this.totalReproductions,
      avgNetSize.toFixed(6),
      Math.max(...generations, 0),
      meanGen.toFixed(6),
      speciesCount,
      meanGenDist.toFixed(6),
      meanFR.toFixed(6),
      maxFR.toFixed(6),
    ].join(','));
  }

  private _saveBestGenome(genome: Genome): void {
    this._bestAgentCounter++;
    const payload = JSON.stringify(genome.toJSON(), null, 2);
    this._bestGenomes.push(payload);
  }

  // ═══════════════════════════════════════════════════════════
  //  MÉTRIQUES POC2.2 — Spéciation, diversité, forage
  // ═══════════════════════════════════════════════════════════

  private _countSpecies(genomes: Genome[]): number {
    const specCfg = this.cfg.speciation;
    const representatives: Genome[] = [];
    for (const genome of genomes) {
      if (!representatives.some(rep => _compatibilityDistance(genome, rep, specCfg) < specCfg.compatibility_threshold)) {
        representatives.push(genome);
      }
    }
    return representatives.length;
  }

  private _meanPairwiseDistance(genomes: Genome[]): number {
    const n = genomes.length;
    if (n < 2) return 0;
    let total = 0;
    let pairs = 0;
    const specCfg = this.cfg.speciation;
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        total += _compatibilityDistance(genomes[i], genomes[j], specCfg);
        pairs++;
      }
    }
    return total / pairs;
  }

  private _forageRates(): number[] {
    return this.agents.map(a => a.foodEaten / Math.max(a.age, 1));
  }

  // ═══════════════════════════════════════════════════════════
  //  ÉTAT POUR LE RENDERER
  // ═══════════════════════════════════════════════════════════

  getState(): SimState {
    const avgEnergy = this.agents.length > 0
      ? this.agents.reduce((s, a) => s + a.energy, 0) / this.agents.length : 0;
    const avgNetSize = this.agents.length > 0
      ? this.agents.reduce((s, a) => s + a.network.networkSize, 0) / this.agents.length : 0;

    let avgLifespan = 0;
    if (this.deadLifespans.length > 0) {
      avgLifespan = this.deadLifespans.reduce((s, v) => s + v, 0) / this.deadLifespans.length;
      this.deadLifespans = [];
    }

    // Métriques poc2.2
    const genomes = this.agents.map(a => a.genome);
    const generations = this.agents.map(a => a.generation);
    const forageRates = this._forageRates();
    const speciesCount = this._countSpecies(genomes);
    const meanGenDist = genomes.length >= 2 ? this._meanPairwiseDistance(genomes) : 0;
    const maxGen = generations.length > 0 ? Math.max(...generations) : 0;
    const meanFR = forageRates.length > 0 ? forageRates.reduce((s, v) => s + v, 0) / forageRates.length : 0;
    const maxFR = forageRates.length > 0 ? Math.max(...forageRates) : 0;

    const best = this.bestAgent;
    return {
      currentTick: this.currentTick,
      population: this.agents.length,
      foodAvailable: this.env.foodAvailable,
      recordApples: this.recordApples,
      totalReproductions: this.totalReproductions,
      avgEnergy: Math.round(avgEnergy * 100) / 100,
      avgNetSize: Math.round(avgNetSize),
      avgLifespan: Math.round(avgLifespan),
      bestAgentFood: best?.foodEaten ?? 0,
      bestAgentEnergy: best ? Math.round(best.energy * 100) / 100 : 0,
      bestAgentAge: best?.age ?? 0,
      bestAgentChildren: best?.childrenCount ?? 0,
      bestAgentNetSize: best?.network.networkSize ?? 0,
      running: this.running,
      seed: this.actualSeed,
      ticksPerFrame: this.ticksPerFrame,
      paused: this.paused,
      maxGeneration: maxGen,
      speciesCount,
      meanGeneticDistance: Math.round(meanGenDist * 1000) / 1000,
      meanForageRate: Math.round(meanFR * 10000) / 10000,
      maxForageRate: Math.round(maxFR * 10000) / 10000,
    };
  }
}

// ═══════════════════════════════════════════════════════════
//  NEAT Compatibility Distance (Stanley & Miikkulainen 2002)
//  δ = c_excess * E + c_disjoint * D + c_weight * W̄
// ═══════════════════════════════════════════════════════════

function _compatibilityDistance(a: Genome, b: Genome, cfg: { c_excess: number; c_disjoint: number; c_weight: number }): number {
  const weightsA = new Map<number, number>();
  const weightsB = new Map<number, number>();
  for (const conn of a.connections.values()) weightsA.set(conn.innovation_id, conn.weight);
  for (const conn of b.connections.values()) weightsB.set(conn.innovation_id, conn.weight);

  if (weightsA.size === 0 && weightsB.size === 0) return 0;

  const innovA = new Set(weightsA.keys());
  const innovB = new Set(weightsB.keys());
  const matching = new Set([...innovA].filter(x => innovB.has(x)));

  const maxA = weightsA.size > 0 ? Math.max(...innovA) : -1;
  const maxB = weightsB.size > 0 ? Math.max(...innovB) : -1;
  const boundary = Math.min(maxA, maxB);

  let excess = 0;
  let disjoint = 0;
  for (const innov of [...innovA, ...innovB]) {
    if (matching.has(innov)) continue;
    if (innov > boundary) excess++;
    else disjoint++;
  }

  let weightDiff = 0;
  if (matching.size > 0) {
    let totalDiff = 0;
    for (const innov of matching) {
      totalDiff += Math.abs(weightsA.get(innov)! - weightsB.get(innov)!);
    }
    weightDiff = totalDiff / matching.size;
  }

  return cfg.c_excess * excess + cfg.c_disjoint * disjoint + cfg.c_weight * weightDiff;
}