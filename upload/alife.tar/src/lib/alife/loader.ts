// ═══════════════════════════════════════════════════════════
//  loader.ts — Charge et valide la config depuis YAML
//  Porté de src/config.py (poc2.2 — step 1)
//
//  Usage serveur/tests uniquement.
//  Le browser utilise DEFAULT_CONFIG directement.
// ═══════════════════════════════════════════════════════════

import * as fs from 'fs';
import * as yaml from 'js-yaml';
import { ConfigError, validateSimConfig } from './config';
import type { SimConfig, EnvironmentConfig, AgentsConfig, MutationsConfig, PopulationConfig, SpeciationConfig, SimulationConfig, LoggingConfig } from './config';

const SECTION_SCHEMAS: Record<string, string[]> = {
  environment: ['env_width', 'env_height', 'zone_width', 'zone_max_drain', 'food_count', 'food_respawn_delay', 'food_energy'],
  agents: ['initial_population', 'max_speed', 'base_drain_rate', 'bootstrap_initial_energy', 'child_initial_energy',
    'reproduction_threshold', 'parent_energy_after_repro', 'max_lifespan', 'lifespan_warning_ticks',
    'agent_radius', 'food_radius', 'ray_max_range', 'num_rays', 'spawn_radius_child', 'max_energy', 'max_turn_rate',
    'vision_boost_max', 'vision_decay_ticks', 'vision_min_multiplier'],
  mutations: ['mutate_weights_prob', 'weight_perturb_prob', 'weight_sigma', 'weight_reset_prob', 'weight_max',
    'add_connection_prob', 'add_node_prob', 'remove_connection_prob', 'remove_node_prob'],
  population: ['initial_population', 'max_population'],
  speciation: ['c_excess', 'c_disjoint', 'c_weight', 'compatibility_threshold'],
  simulation: ['tick_rate', 'render_fps', 'log_interval', 'seed', 'headless'],
  logging: ['csv_path', 'log_interval_ticks', 'best_genome_path'],
};

function _buildSection<T>(data: Record<string, unknown>, section: string, required: boolean = true): T {
  if (!(section in data)) {
    if (required) throw new ConfigError(`missing config section '${section}'`);
    return {} as T;
  }
  const payload = data[section];
  if (typeof payload !== 'object' || payload === null || Array.isArray(payload)) {
    throw new ConfigError(`config section '${section}' must be a mapping`);
  }
  const allowed = new Set(SECTION_SCHEMAS[section] ?? []);
  const payloadKeys = Object.keys(payload as Record<string, unknown>);
  const unknown = payloadKeys.filter(k => !allowed.has(k));
  if (unknown.length > 0) {
    throw new ConfigError(`unknown key(s) [${unknown.sort().join(', ')}] in section '${section}'`);
  }
  const missing = [...allowed].filter(k => !(k in (payload as Record<string, unknown>)));
  if (missing.length > 0) {
    throw new ConfigError(`missing key(s) [${missing.sort().join(', ')}] in section '${section}'`);
  }
  return payload as T;
}

/**
 * Charge une config depuis un fichier YAML, valide cross-section invariants.
 * Uniquement disponible côté serveur / tests (utilise fs).
 */
export function loadConfigFromYaml(path: string): SimConfig {
  let text: string;
  try {
    text = fs.readFileSync(path, 'utf-8');
  } catch (err) {
    throw new ConfigError(`cannot read config file '${path}': ${(err as Error).message}`);
  }

  let data: unknown;
  try {
    data = yaml.load(text);
  } catch (err) {
    throw new ConfigError(`invalid YAML in '${path}': ${(err as Error).message}`);
  }

  if (typeof data !== 'object' || data === null || Array.isArray(data)) {
    throw new ConfigError('configuration root must be a mapping');
  }

  const raw = data as Record<string, unknown>;

  const cfg: SimConfig = {
    environment: _buildSection<EnvironmentConfig>(raw, 'environment'),
    agents: _buildSection<AgentsConfig>(raw, 'agents'),
    mutations: _buildSection<MutationsConfig>(raw, 'mutations'),
    population: _buildSection<PopulationConfig>(raw, 'population'),
    speciation: _buildSection<SpeciationConfig>(raw, 'speciation'),
    simulation: _buildSection<SimulationConfig>(raw, 'simulation'),
    logging: _buildSection<LoggingConfig>(raw, 'logging', false),
  };

  validateSimConfig(cfg);
  return cfg;
}

/**
 * Construit une SimConfig depuis un dict déjà parsé (pour les tests).
 */
export function configFromDict(data: Record<string, unknown>): SimConfig {
  const cfg: SimConfig = {
    environment: _buildSection<EnvironmentConfig>(data, 'environment'),
    agents: _buildSection<AgentsConfig>(data, 'agents'),
    mutations: _buildSection<MutationsConfig>(data, 'mutations'),
    population: _buildSection<PopulationConfig>(data, 'population'),
    speciation: _buildSection<SpeciationConfig>(data, 'speciation'),
    simulation: _buildSection<SimulationConfig>(data, 'simulation'),
    logging: _buildSection<LoggingConfig>(data, 'logging', false),
  };
  validateSimConfig(cfg);
  return cfg;
}