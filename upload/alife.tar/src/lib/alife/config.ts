// ═══════════════════════════════════════════════════════════
//  config.ts — Configuration ALife —valeurs conformes au CDC v5 §10
//  Zéro valeur hardcodée dans le code source (CDC §10)
// ═══════════════════════════════════════════════════════════

export interface EnvironmentConfig {
  env_width: number;
  env_height: number;
  zone_width: number;
  zone_max_drain: number;
  food_count: number;
  food_respawn_delay: number;
  food_energy: number;
}

export interface AgentsConfig {
  initial_population: number;
  max_speed: number;
  base_drain_rate: number;
  bootstrap_initial_energy: number;
  child_initial_energy: number;
  reproduction_threshold: number;
  parent_energy_after_repro: number;
  max_lifespan: number;
  lifespan_warning_ticks: number;
  agent_radius: number;
  food_radius: number;
  ray_max_range: number;
  num_rays: number;
  spawn_radius_child: number;
  max_energy: number;
  max_turn_rate: number;  // rad/tick — cap égocentrique (poc2.2 step 4)
  // Vision dynamique (plasticité phénotypique)
  vision_boost_max: number;      // multiplicateur max juste après avoir mangé (ex: 1.5)
  vision_decay_ticks: number;    // ticks pour passer du boost au minimum
  vision_min_multiplier: number; // multiplicateur min quand affamé (ex: 0.4)
}

export interface MutationsConfig {
  mutate_weights_prob: number;
  weight_perturb_prob: number;
  weight_sigma: number;
  weight_reset_prob: number;
  weight_max: number;           // Clamp après mutation (anti-saturation, NEAT canonique)
  add_connection_prob: number;
  add_node_prob: number;
  remove_connection_prob: number;
  remove_node_prob: number;
}

export interface PopulationConfig {
  initial_population: number;
  max_population: number;     // Cap population (sélection au plafond)
}

export interface SpeciationConfig {
  c_excess: number;
  c_disjoint: number;
  c_weight: number;
  compatibility_threshold: number;
}

export interface SimulationConfig {
  tick_rate: number;
  render_fps: number;
  log_interval: number;
  seed: number;
  headless: boolean;
}

export interface LoggingConfig {
  csv_path: string;
  log_interval_ticks: number;
  best_genome_path: string;
}

export interface SimConfig {
  environment: EnvironmentConfig;
  agents: AgentsConfig;
  mutations: MutationsConfig;
  population: PopulationConfig;
  speciation: SpeciationConfig;
  simulation: SimulationConfig;
  logging?: LoggingConfig;
}

// ── Default config — valeurs identiques au CDC v5 §10 ──────────

export const DEFAULT_CONFIG: SimConfig = {
  // CDC §10 — Environnement
  environment: {
    env_width: 800,
    env_height: 800,
    zone_width: 60,
    zone_max_drain: 0.10,         // Doublé : pénalité murale plus sévère pour décourager l'errance near-wall
    food_count: 30,
    food_respawn_delay: 150,
    food_energy: 1.0,
  },
  // CDC §10 — Agents (§4 + §5)
  agents: {
    initial_population: 30,
    max_speed: 2.0,
    base_drain_rate: 0.008,       // Augmenté : ~500 ticks pour mourir de faim (vs 800 avant)
    bootstrap_initial_energy: 4.0,    // = reproduction_threshold − 1 (CDC §4.2)
    child_initial_energy: 2.0,
    reproduction_threshold: 5.0,
    parent_energy_after_repro: 1.0,
    max_lifespan: 3000,           // Réduit : force la recherche active (10000 → 3000)
    lifespan_warning_ticks: 500,
    agent_radius: 10,
    food_radius: 7,
    ray_max_range: 200,
    num_rays: 16,
    spawn_radius_child: 75,          // CDC §10 : 75 (dans la plage 50–100)
    max_energy: 10.0,
    max_turn_rate: 0.2,           // rad/tick — cap égocentrique (poc2.2 step 4)
    // Vision dynamique (plasticité phénotypique)
    vision_boost_max: 1.5,       // ×1.5 portée juste après un repas
    vision_decay_ticks: 400,     // 400 ticks pour revenir au minimum
    vision_min_multiplier: 0.4,  // ×0.4 portée quand très affamé
  },
  // CDC §10 — Mutations (§2.2)
  mutations: {
    mutate_weights_prob: 0.80,
    weight_perturb_prob: 0.15,
    weight_sigma: 0.2,
    weight_reset_prob: 0.05,
    weight_max: 5.0,               // Anti-saturation (poc2.2)
    add_connection_prob: 0.05,
    add_node_prob: 0.03,
    remove_connection_prob: 0.05,
    remove_node_prob: 0.02,
  },
  // Population (poc2.2 — sélection au plafond)
  population: {
    initial_population: 30,
    max_population: 150,
  },
  // Spéciation — observateurs en lecture seule (poc2.2)
  // NEAT compatibility distance (Stanley & Miikkulainen 2002)
  speciation: {
    c_excess: 1.0,
    c_disjoint: 1.0,
    c_weight: 0.4,
    compatibility_threshold: 3.0,
  },
  // CDC §10 — Simulation
  simulation: {
    tick_rate: 60,
    render_fps: 60,
    log_interval: 100,
    seed: 42,
    headless: false,
  },
  // Logging (poc2.2 — step 1)
  logging: {
    csv_path: 'logs/metrics.csv',
    log_interval_ticks: 100,
    best_genome_path: 'logs/best_genome.json',
  },
};

// ═══════════════════════════════════════════════════════════
//  Validation (poc2.2 — step 1)
// ═══════════════════════════════════════════════════════════

export class ConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ConfigError';
  }
}

/**
 * Valide les invariants cross-section de la configuration.
 * Porté de src/config.py — SimConfig.__post_init__
 */
export function validateSimConfig(cfg: SimConfig): void {
  const a = cfg.agents;
  const m = cfg.mutations;
  const e = cfg.environment;
  const p = cfg.population;
  const s = cfg.speciation;

  // Validation locale — valeurs positives
  _requirePositive(a, 'max_speed', 'bootstrap_initial_energy', 'child_initial_energy',
    'reproduction_threshold', 'max_lifespan', 'lifespan_warning_ticks',
    'agent_radius', 'food_radius', 'ray_max_range', 'num_rays', 'spawn_radius_child', 'max_energy', 'max_turn_rate',
    'vision_boost_max', 'vision_decay_ticks');
  _requirePositive(a, 'vision_min_multiplier');
  _requireNonNegative(a, 'base_drain_rate');
  _requirePositive(e, 'env_width', 'env_height', 'food_count', 'food_respawn_delay', 'food_energy');
  _requirePositive(m, 'weight_max');
  _requireRate(m, 'mutate_weights_prob', 'weight_perturb_prob', 'weight_reset_prob',
    'add_connection_prob', 'add_node_prob', 'remove_connection_prob', 'remove_node_prob');
  _requirePositive(p, 'initial_population', 'max_population');
  _requireNonNegative(s, 'c_excess', 'c_disjoint', 'c_weight');
  _requirePositive(s, 'compatibility_threshold');

  // Cross-validation
  const expectedInputs = 3 * a.num_rays + 1;
  // (pas de champ network.num_inputs dans notre config — vérifié à la construction)

  // Zone pénalité ne doit pas couvrir plus de la moitié du monde
  if (e.zone_width >= Math.min(e.env_width, e.env_height) / 2) {
    throw new ConfigError(
      'environment.zone_width must be smaller than half the smallest world dimension',
    );
  }

  // Coût de reproduction ≤ seuil
  if (a.parent_energy_after_repro >= a.reproduction_threshold) {
    throw new ConfigError(
      'agents.parent_energy_after_repro must be < agents.reproduction_threshold',
    );
  }

  // max_energy ≥ bootstrap_initial_energy
  if (a.max_energy < a.bootstrap_initial_energy) {
    throw new ConfigError('agents.max_energy must be >= agents.bootstrap_initial_energy');
  }

  // Population : initial ≤ max
  if (p.initial_population > p.max_population) {
    throw new ConfigError(
      'population.initial_population must be <= population.max_population',
    );
  }

  // Logging validation
  if (cfg.logging) {
    _requirePositive(cfg.logging, 'log_interval_ticks');
    if (!cfg.logging.csv_path) throw new ConfigError('logging.csv_path must be non-empty');
    if (!cfg.logging.best_genome_path) throw new ConfigError('logging.best_genome_path must be non-empty');
  }
}

function _requirePositive(obj: Record<string, number>, ...names: string[]): void {
  for (const name of names) {
    const v = obj[name];
    if (v === undefined) continue;
    if (typeof v !== 'number' || v <= 0) {
      throw new ConfigError(`${name} must be > 0, got ${v}`);
    }
  }
}

function _requireNonNegative(obj: Record<string, number>, ...names: string[]): void {
  for (const name of names) {
    const v = obj[name];
    if (v === undefined) continue;
    if (typeof v !== 'number' || v < 0) {
      throw new ConfigError(`${name} must be >= 0, got ${v}`);
    }
  }
}

function _requireRate(obj: Record<string, number>, ...names: string[]): void {
  for (const name of names) {
    const v = obj[name];
    if (v === undefined) continue;
    if (typeof v !== 'number' || v < 0 || v > 1) {
      throw new ConfigError(`${name} must be in [0, 1], got ${v}`);
    }
  }
}