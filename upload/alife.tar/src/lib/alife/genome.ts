// ═══════════════════════════════════════════════════════════
//  genome.ts — Genome: nodes, connections, mutations (asexué)
//  CDC v5 §2 : topologie évolutive, mutations structurelles
//  Reproduction asexuée uniquement (clone + mutate) — CDC §2.3
//  Hors scope v1 : crossover, spéciation (CDC §11)
//
//  Écart positif documenté (remarque prof) :
//    ray_range est un trait évolutif par génome, sélectionné
//    naturellement. Plage initiale [40, 150] pour favoriser
//    l'exploration active (remarque : "rayon plus petit").
// ═══════════════════════════════════════════════════════════

import type { MutationsConfig } from './config';

// ── Enums ──────────────────────────────────────────────────

export enum NodeType {
  INPUT = 'INPUT',
  HIDDEN = 'HIDDEN',
  OUTPUT = 'OUTPUT',
}

// ── Gene types ─────────────────────────────────────────────

export interface NodeGene {
  id: number;
  type: NodeType;
  activation: string;
}

export interface ConnectionGene {
  in_node_id: number;
  out_node_id: number;
  weight: number;
  enabled: boolean;
  innovation_id: number;
}

// ── Innovation Counter (singleton) ────────────────────────

class InnovationCounterClass {
  private static instance: InnovationCounterClass;
  private value = 0;

  private constructor() {}

  static getInstance(): InnovationCounterClass {
    if (!InnovationCounterClass.instance) {
      InnovationCounterClass.instance = new InnovationCounterClass();
    }
    return InnovationCounterClass.instance;
  }

  get nextId(): number {
    this.value += 1;
    return this.value;
  }

  get current(): number {
    return this.value;
  }

  reset(): void {
    this.value = 0;
  }

  syncTo(value: number): void {
    if (value >= this.value) {
      this.value = value;
    }
  }
}

export const InnovationCounter = InnovationCounterClass.getInstance;

// ── Seeded PRNG (Mulberry32) ─────────────────────────────

export class SeededRNG {
  private state: number;

  constructor(seed: number) {
    this.state = seed;
  }

  /** Returns float in [0, 1) */
  next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /** Float in [min, max) */
  uniform(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  /** Gaussian via Box-Muller */
  gauss(mean: number, std: number): number {
    const u1 = this.next() || 1e-10;
    const u2 = this.next();
    return mean + std * Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  }

  /** Random int in [0, max) */
  int(max: number): number {
    return Math.floor(this.next() * max);
  }

  /** Pick random element from array */
  pick<T>(arr: T[]): T {
    return arr[this.int(arr.length)];
  }

  /** Pick N random elements (without replacement) */
  sample<T>(arr: T[], n: number): T[] {
    const copy = [...arr];
    const result: T[] = [];
    const count = Math.min(n, copy.length);
    for (let i = 0; i < count; i++) {
      const idx = this.int(copy.length - i);
      result.push(copy.splice(idx, 1)[0]);
    }
    return result;
  }
}

// ── Genome ────────────────────────────────────────────────

export class Genome {
  num_inputs: number;
  num_outputs: number;
  nodes: Map<number, NodeGene> = new Map();
  connections: Map<string, ConnectionGene> = new Map();
  private _nextHiddenId: number;
  ray_range: number;
  private _rng: SeededRNG;

  constructor(num_inputs: number, num_outputs: number, rng: SeededRNG) {
    this.num_inputs = num_inputs;
    this.num_outputs = num_outputs;
    this._rng = rng;
    this._nextHiddenId = num_inputs + num_outputs;
    // Écart positif : ray_range évolutif (remarque prof)
    // Plage initiale [40, 150] plutôt que fixe à 200 → favorise l'exploration
    this.ray_range = rng.uniform(40, 150);
    this._buildFullyConnected();
  }

  private _buildFullyConnected(): void {
    for (let i = 0; i < this.num_inputs; i++) {
      this.nodes.set(i, { id: i, type: NodeType.INPUT, activation: 'tanh' });
    }
    for (let i = 0; i < this.num_outputs; i++) {
      const oid = this.num_inputs + i;
      this.nodes.set(oid, { id: oid, type: NodeType.OUTPUT, activation: 'tanh' });
    }
    const ic = InnovationCounter();
    for (let i = 0; i < this.num_inputs; i++) {
      for (let j = 0; j < this.num_outputs; j++) {
        const oid = this.num_inputs + j;
        this.connections.set(`${i},${oid}`, {
          in_node_id: i,
          out_node_id: oid,
          weight: this._rng.uniform(-1, 1),
          enabled: true,
          innovation_id: ic.nextId,
        });
      }
    }
  }

  get inputIds(): number[] {
    return [...this.nodes.values()].filter(n => n.type === NodeType.INPUT).map(n => n.id).sort((a, b) => a - b);
  }

  get outputIds(): number[] {
    return [...this.nodes.values()].filter(n => n.type === NodeType.OUTPUT).map(n => n.id).sort((a, b) => a - b);
  }

  get hiddenIds(): number[] {
    return [...this.nodes.values()].filter(n => n.type === NodeType.HIDDEN).map(n => n.id);
  }

  get enabledConnections(): ConnectionGene[] {
    return [...this.connections.values()].filter(c => c.enabled);
  }

  get connectionCount(): number {
    return [...this.connections.values()].filter(c => c.enabled).length;
  }

  get maxInnovation(): number {
    const conns = [...this.connections.values()];
    if (conns.length === 0) return 0;
    return Math.max(...conns.map(c => c.innovation_id));
  }

  connKey(inId: number, outId: number): string {
    return `${inId},${outId}`;
  }

  deepCopy(): Genome {
    const g = Object.create(Genome.prototype) as Genome;
    g.num_inputs = this.num_inputs;
    g.num_outputs = this.num_outputs;
    g._rng = this._rng;
    g._nextHiddenId = this._nextHiddenId;
    g.ray_range = this.ray_range;
    g.nodes = new Map();
    for (const [id, n] of this.nodes) {
      g.nodes.set(id, { ...n });
    }
    g.connections = new Map();
    for (const [k, c] of this.connections) {
      g.connections.set(k, { ...c });
    }
    return g;
  }

  // ── Sérialisation JSON (poc2.2 — step 6) ──

  toJSON(): object {
    return {
      num_inputs: this.num_inputs,
      num_outputs: this.num_outputs,
      ray_range: this.ray_range,
      nodes: [...this.nodes.values()].map(n => ({ id: n.id, type: n.type })),
      connections: [...this.connections.values()].map(c => ({
        in: c.in_node_id,
        out: c.out_node_id,
        weight: c.weight,
        enabled: c.enabled,
        innovation: c.innovation_id,
      })),
    };
  }

  static fromJSON(data: object): Genome {
    const d = data as {
      num_inputs: number;
      num_outputs: number;
      ray_range: number;
      nodes: { id: number; type: string }[];
      connections: {
        in: number; out: number; weight: number; enabled: boolean; innovation: number;
      }[];
    };
    const g = Object.create(Genome.prototype) as Genome;
    g.num_inputs = d.num_inputs;
    g.num_outputs = d.num_outputs;
    g.ray_range = d.ray_range;
    g._rng = null as unknown as SeededRNG;
    g._nextHiddenId = Math.max(0, ...d.nodes.map(n => n.id)) + 1;
    g.nodes = new Map();
    for (const n of d.nodes) {
      g.nodes.set(n.id, { id: n.id, type: n.type as NodeType, activation: 'tanh' });
    }
    g.connections = new Map();
    for (const c of d.connections) {
      g.connections.set(g.connKey(c.in, c.out), {
        in_node_id: c.in,
        out_node_id: c.out,
        weight: c.weight,
        enabled: c.enabled,
        innovation_id: c.innovation,
      });
    }
    return g;
  }

  // ── Mutations (CDC §2.2) ──

  mutate(cfg: MutationsConfig): void {
    const rng = this._rng;
    if (rng.next() < cfg.mutate_weights_prob) this._mutateWeights(cfg);
    if (rng.next() < cfg.add_connection_prob) this._mutateAddConnection();
    if (rng.next() < cfg.add_node_prob) this._mutateAddNode();
    if (rng.next() < cfg.remove_connection_prob) this._mutateRemoveConnection();
    if (rng.next() < cfg.remove_node_prob) this._mutateRemoveNode();
    this._mutateToggleConnections();
  }

  private _mutateWeights(cfg: MutationsConfig): void {
    const rng = this._rng;
    const wMax = cfg.weight_max;
    for (const conn of this.connections.values()) {
      const r = rng.next();
      if (r < cfg.weight_perturb_prob) {
        conn.weight += rng.gauss(0, cfg.weight_sigma);
        conn.weight = Math.max(-wMax, Math.min(wMax, conn.weight)); // clamp
      } else if (r < cfg.weight_perturb_prob + cfg.weight_reset_prob) {
        conn.weight = rng.uniform(-1, 1);
      }
    }
    if (rng.next() < cfg.weight_perturb_prob) {
      this.ray_range += rng.gauss(0, 15);
      // Plage évolutive [20, 200] — bornée par ray_max_range du CDC
      this.ray_range = Math.max(20, Math.min(this.ray_range, 200));
    }
  }

  private _mutateAddConnection(): void {
    const rng = this._rng;
    const allIds = [...this.nodes.keys()];
    for (let attempt = 0; attempt < 10; attempt++) {
      const [a, b] = rng.sample(allIds, 2);
      const nodeB = this.nodes.get(b)!;
      if (nodeB.type === NodeType.INPUT) continue;

      const keyAB = this.connKey(a, b);
      const keyBA = this.connKey(b, a);

      if (!this.connections.has(keyAB) && !this.connections.has(keyBA)) {
        const ic = InnovationCounter();
        if (!this._wouldCreateCycle(a, b)) {
          this.connections.set(keyAB, {
            in_node_id: a, out_node_id: b,
            weight: rng.uniform(-1, 1), enabled: true, innovation_id: ic.nextId,
          });
          return;
        } else if (!this._wouldCreateCycle(b, a)) {
          this.connections.set(keyBA, {
            in_node_id: b, out_node_id: a,
            weight: rng.uniform(-1, 1), enabled: true, innovation_id: ic.nextId,
          });
          return;
        }
      }
    }
  }

  private _mutateAddNode(): void {
    const enabled = this.enabledConnections;
    if (enabled.length === 0) return;

    const rng = this._rng;
    const conn = rng.pick(enabled);
    const connKey = this.connKey(conn.in_node_id, conn.out_node_id);
    conn.enabled = false;

    const newId = this._nextHiddenId++;
    this.nodes.set(newId, { id: newId, type: NodeType.HIDDEN, activation: 'tanh' });

    const ic = InnovationCounter();
    this.connections.set(this.connKey(conn.in_node_id, newId), {
      in_node_id: conn.in_node_id, out_node_id: newId,
      weight: 1.0, enabled: true, innovation_id: ic.nextId,
    });
    this.connections.set(this.connKey(newId, conn.out_node_id), {
      in_node_id: newId, out_node_id: conn.out_node_id,
      weight: conn.weight, enabled: true, innovation_id: ic.nextId,
    });
  }

  private _mutateRemoveConnection(): void {
    const rng = this._rng;
    const disabled = [...this.connections.values()].filter(c => !c.enabled);
    if (disabled.length > 0 && rng.next() < 0.7) {
      const conn = rng.pick(disabled);
      this.connections.delete(this.connKey(conn.in_node_id, conn.out_node_id));
      return;
    }
    const enabled = this.enabledConnections;
    if (enabled.length <= this.num_outputs) return;

    // BUG FIX : ne jamais supprimer la dernière connexion entrante d'un output
    // sinon vx=0, vy=0 → créature figée à jamais
    const outputIds = this.outputIds;
    const inputCountPerOutput = new Map<number, number>();
    for (const oid of outputIds) inputCountPerOutput.set(oid, 0);
    for (const conn of enabled) {
      const cnt = inputCountPerOutput.get(conn.out_node_id);
      if (cnt !== undefined) inputCountPerOutput.set(conn.out_node_id, cnt + 1);
    }

    // On ne tire que parmi les connexions dont la suppression ne déconnecte pas un output
    const safeCandidates = enabled.filter(c => {
      const cnt = inputCountPerOutput.get(c.out_node_id);
      return cnt !== undefined && cnt > 1;
    });

    if (safeCandidates.length > 0) {
      const conn = rng.pick(safeCandidates);
      this.connections.delete(this.connKey(conn.in_node_id, conn.out_node_id));
    }
    // Si aucun candidat sûr, on ne supprime rien → on protège les outputs
  }

  private _mutateRemoveNode(): void {
    const hidden = this.hiddenIds;
    if (hidden.length === 0) return;

    const rng = this._rng;
    const nodeId = rng.pick(hidden);

    // BUG FIX : vérifier que chaque output gardera au moins 1 connexion active
    const outputIds = this.outputIds;
    const enabledCountPerOutput = new Map<number, number>();
    for (const oid of outputIds) enabledCountPerOutput.set(oid, 0);
    for (const conn of this.connections.values()) {
      if (conn.enabled && conn.out_node_id !== nodeId && conn.in_node_id !== nodeId) {
        const cnt = enabledCountPerOutput.get(conn.out_node_id);
        if (cnt !== undefined) enabledCountPerOutput.set(conn.out_node_id, cnt + 1);
      }
    }
    // Si un output aurait 0 connexion restante, annuler la suppression
    for (const oid of outputIds) {
      if ((enabledCountPerOutput.get(oid) || 0) === 0) return;
    }

    this.nodes.delete(nodeId);
    for (const [key] of this.connections) {
      const [a, b] = key.split(',').map(Number);
      if (a === nodeId || b === nodeId) this.connections.delete(key);
    }
  }

  private _mutateToggleConnections(): void {
    const rng = this._rng;
    // BUG FIX : compter les connexions actives par output AVANT de toggler
    const outputIds = this.outputIds;
    const enabledCountPerOutput = new Map<number, number>();
    for (const oid of outputIds) enabledCountPerOutput.set(oid, 0);
    for (const conn of this.connections.values()) {
      if (conn.enabled) {
        const cnt = enabledCountPerOutput.get(conn.out_node_id);
        if (cnt !== undefined) enabledCountPerOutput.set(conn.out_node_id, cnt + 1);
      }
    }

    for (const conn of this.connections.values()) {
      if (rng.next() < 0.02) {
        // Ne jamais désactiver la dernière connexion entrante d'un output
        if (conn.enabled) {
          const cnt = enabledCountPerOutput.get(conn.out_node_id);
          if (cnt !== undefined && cnt <= 1) continue; // protéger cet output
        }
        conn.enabled = !conn.enabled;
        // Mettre à jour le compteur
        const cnt = enabledCountPerOutput.get(conn.out_node_id);
        if (cnt !== undefined) {
          enabledCountPerOutput.set(conn.out_node_id, conn.enabled ? cnt + 1 : cnt - 1);
        }
      }
    }
  }

  // ── Cycle detection (DFS) ──

  private _wouldCreateCycle(fromId: number, toId: number): boolean {
    const visited = new Set<number>();
    const stack = [toId];

    // Build adjacency list
    const adj = new Map<number, number[]>();
    for (const nid of this.nodes.keys()) adj.set(nid, []);
    for (const c of this.connections.values()) {
      if (c.enabled) {
        const list = adj.get(c.in_node_id) || [];
        list.push(c.out_node_id);
        adj.set(c.in_node_id, list);
      }
    }

    while (stack.length > 0) {
      const current = stack.pop()!;
      if (current === fromId) return true;
      if (visited.has(current)) continue;
      visited.add(current);
      for (const neighbor of (adj.get(current) || [])) {
        stack.push(neighbor);
      }
    }
    return false;
  }
}