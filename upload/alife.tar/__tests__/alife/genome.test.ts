// ═══════════════════════════════════════════════════════════
//  Tests Genome — port de test_genome.py (poc2.2 step 7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect, beforeEach } from 'vitest';
import { Genome, SeededRNG, InnovationCounter, NodeType } from '@/lib/alife/genome';
import { DEFAULT_CONFIG } from '@/lib/alife/config';

const NUM_INPUTS = 49;
const NUM_OUTPUTS = 2;
const mutCfg = DEFAULT_CONFIG.mutations;

let rng: SeededRNG;

beforeEach(() => {
  InnovationCounter().reset();
  rng = new SeededRNG(42);
});

function makeGenome(seed = 42): Genome {
  InnovationCounter().reset();
  return new Genome(NUM_INPUTS, NUM_OUTPUTS, new SeededRNG(seed));
}

// ── Construction ──

describe('Genome construction', () => {
  it('fully connected shape', () => {
    const g = makeGenome();
    const inputs = [...g.nodes.values()].filter(n => n.type === NodeType.INPUT);
    const outputs = [...g.nodes.values()].filter(n => n.type === NodeType.OUTPUT);
    expect(inputs.length).toBe(NUM_INPUTS);
    expect(outputs.length).toBe(NUM_OUTPUTS);
    expect(g.connectionCount).toBe(NUM_INPUTS * NUM_OUTPUTS);
    expect(g.enabledConnections.length).toBe(NUM_INPUTS * NUM_OUTPUTS);
  });

  it('node ids are unique', () => {
    const g = makeGenome();
    const ids = [...g.nodes.keys()];
    expect(ids.length).toBe(new Set(ids).size);
  });

  it('weights within init range', () => {
    const g = makeGenome(7);
    for (const c of g.connections.values()) {
      expect(c.weight).toBeGreaterThanOrEqual(-1);
      expect(c.weight).toBeLessThanOrEqual(1);
    }
  });
});

// ── Clone ──

describe('Genome clone', () => {
  it('deepCopy is independent', () => {
    const g = makeGenome(2);
    const clone = g.deepCopy();
    const firstConn = [...clone.connections.values()][0];
    firstConn.weight += 100;
    clone.nodes.set(999, { id: 999, type: NodeType.HIDDEN, activation: 'tanh' });
    expect([...g.connections.values()][0].weight).not.toBe(firstConn.weight);
    expect(g.nodes.has(999)).toBe(false);
  });
});

// ── Sérialisation JSON (step 6) ──

describe('Genome serialization', () => {
  it('JSON round-trip', () => {
    const g = makeGenome(3);
    const json = g.toJSON();
    const restored = Genome.fromJSON(json);
    const restoredJson = restored.toJSON();
    expect(JSON.stringify(json)).toBe(JSON.stringify(restoredJson));
  });

  it('serialized has correct fields', () => {
    const g = makeGenome(3);
    const json = g.toJSON() as any;
    expect(json.num_inputs).toBe(NUM_INPUTS);
    expect(json.num_outputs).toBe(NUM_OUTPUTS);
    expect(json.ray_range).toBe(g.ray_range);
    expect(json.nodes.length).toBe(g.nodes.size);
    expect(json.connections.length).toBe(g.connections.size);
  });
});

// ── Innovation Counter ──

describe('Innovation counter', () => {
  it('same edge same innovation', () => {
    const g = makeGenome();
    const conns = [...g.connections.values()];
    // Find two connections that share an endpoint
    if (conns.length >= 2) {
      const key1 = `${conns[0].in_node_id},${conns[0].out_node_id}`;
      expect(g.connections.has(key1)).toBe(true);
    }
  });

  it('reset clears counters', () => {
    InnovationCounter().reset();
    const ic = InnovationCounter();
    ic.nextId;
    ic.nextId;
    ic.reset();
    expect(ic.current).toBe(0);
  });
});

// ── Mutations ──

describe('Genome mutations', () => {
  it('mutate changes weights', () => {
    const g = makeGenome(4);
    const before = [...g.connections.values()].map(c => c.weight);
    g.mutate(mutCfg);
    const after = [...g.connections.values()].map(c => c.weight);
    expect(before).not.toEqual(after);
  });

  it('add node splits connection', () => {
    const g = makeGenome(5);
    const nNodes = g.nodes.size;
    const nConns = g.connections.size;
    // Force add node by directly calling
    g._mutateAddNode();
    expect(g.nodes.size).toBe(nNodes + 1);
    // Should have +1 node and +2 connections (split creates 2, disables 1 = net +1)
    expect(g.connections.size).toBe(nConns + 2);
    const hiddens = [...g.nodes.values()].filter(n => n.type === NodeType.HIDDEN);
    expect(hiddens.length).toBe(1);
    const disabled = [...g.connections.values()].filter(c => !c.enabled);
    expect(disabled.length).toBe(1);
  });

  it('add connection no cycles', () => {
    const g = makeGenome(6);
    // Add a hidden node first
    g._mutateAddNode();
    for (let i = 0; i < 100; i++) {
      g._mutateAddConnection();
    }
    // Verify no self-loops
    for (const c of g.connections.values()) {
      expect(c.in_node_id).not.toBe(c.out_node_id);
    }
  });

  it('weights clamped after mutation', () => {
    const g = makeGenome(99);
    // Force weights far outside clamp range
    for (const c of g.connections.values()) {
      c.weight = 100.0;
    }
    for (let i = 0; i < 50; i++) {
      g._mutateWeights(mutCfg);
    }
    for (const c of g.connections.values()) {
      expect(Math.abs(c.weight)).toBeLessThanOrEqual(mutCfg.weight_max);
    }
  });
});

// ── Determinism ──

describe('Determinism', () => {
  it('mutation is deterministic with seed', () => {
    const build = () => {
      InnovationCounter().reset();
      const g = new Genome(NUM_INPUTS, NUM_OUTPUTS, new SeededRNG(123));
      for (let i = 0; i < 10; i++) g.mutate(mutCfg);
      return g.toJSON();
    };
    expect(JSON.stringify(build())).toBe(JSON.stringify(build()));
  });
});