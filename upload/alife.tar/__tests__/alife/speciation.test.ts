// ═══════════════════════════════════════════════════════════
//  Tests Spéciation — port de test_speciation.py (poc2.2 step 7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect, beforeEach } from 'vitest';
import { Genome, SeededRNG, InnovationCounter } from '@/lib/alife/genome';
import { DEFAULT_CONFIG } from '@/lib/alife/config';

const specCfg = DEFAULT_CONFIG.speciation;
const mutCfg = DEFAULT_CONFIG.mutations;
const NUM_INPUTS = 33;
const NUM_OUTPUTS = 2;

function _fresh(seed: number): Genome {
  InnovationCounter().reset();
  return new Genome(NUM_INPUTS, NUM_OUTPUTS, new SeededRNG(seed));
}

// Compatibility distance (copied from simulation.ts logic)
function compatibilityDistance(a: Genome, b: Genome): number {
  const weightsA = new Map<number, number>();
  const weightsB = new Map<number, number>();
  for (const conn of a.connections.values()) weightsA.set(conn.innovation_id, conn.weight);
  for (const conn of b.connections.values()) weightsB.set(conn.innovation_id, conn.weight);

  if (weightsA.size === 0 && weightsB.size === 0) return 0;

  const innovA = new Set(weightsA.keys());
  const innovB = new Set(weightsB.keys());
  const matching = new Set([...innovA].filter(x => innovB.has(x)));

  const maxA = weightsA.size > 0 ? Math.max(...innovA) : -1;
  const maxB = weightsB.size > 0 ? Math.max(...innovB) : -1;
  const boundary = Math.min(maxA, maxB);

  let excess = 0;
  let disjoint = 0;
  for (const innov of [...innovA, ...innovB]) {
    if (matching.has(innov)) continue;
    if (innov > boundary) excess++;
    else disjoint++;
  }

  let weightDiff = 0;
  if (matching.size > 0) {
    let totalDiff = 0;
    for (const innov of matching) {
      totalDiff += Math.abs(weightsA.get(innov)! - weightsB.get(innov)!);
    }
    weightDiff = totalDiff / matching.size;
  }

  return specCfg.c_excess * excess + specCfg.c_disjoint * disjoint + specCfg.c_weight * weightDiff;
}

function countSpecies(genomes: Genome[]): number {
  const representatives: Genome[] = [];
  for (const genome of genomes) {
    if (!representatives.some(rep => compatibilityDistance(genome, rep) < specCfg.compatibility_threshold)) {
      representatives.push(genome);
    }
  }
  return representatives.length;
}

function meanPairwiseDistance(genomes: Genome[]): number {
  const n = genomes.length;
  if (n < 2) return 0;
  let total = 0;
  let pairs = 0;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      total += compatibilityDistance(genomes[i], genomes[j]);
      pairs++;
    }
  }
  return total / pairs;
}

// ── compatibility_distance ──

describe('Compatibility distance', () => {
  it('identical genomes distance zero', () => {
    const genome = _fresh(1);
    expect(compatibilityDistance(genome, genome.deepCopy())).toBeCloseTo(0);
  });

  it('weight difference drives distance', () => {
    const genome = _fresh(2);
    const twin = genome.deepCopy();
    const delta = 4.0;
    const firstConn = [...twin.connections.values()][0];
    firstConn.weight += delta;
    const n = genome.connections.size;
    const expected = specCfg.c_weight * (delta / n);
    expect(compatibilityDistance(genome, twin)).toBeCloseTo(expected);
  });

  it('structural difference increases distance', () => {
    InnovationCounter().reset();
    const genome = new Genome(NUM_INPUTS, NUM_OUTPUTS, new SeededRNG(3));
    const mutant = genome.deepCopy();
    mutant._mutateAddNode();
    mutant._mutateAddNode();
    // Two splits introduce 4 excess innovations
    const dist = compatibilityDistance(genome, mutant);
    expect(dist).toBeGreaterThanOrEqual(specCfg.c_excess * 4);
  });
});

// ── count_species ──

describe('Count species', () => {
  it('clones form single species', () => {
    const genome = _fresh(4);
    const population = Array.from({ length: 10 }, () => genome.deepCopy());
    expect(countSpecies(population)).toBe(1);
  });

  it('empty population zero species', () => {
    expect(countSpecies([])).toBe(0);
  });
});

// ── mean_pairwise_distance ──

describe('Mean pairwise distance', () => {
  it('needs two', () => {
    expect(meanPairwiseDistance([])).toBe(0);
    expect(meanPairwiseDistance([_fresh(6)])).toBe(0);
  });

  it('zero for clones', () => {
    const genome = _fresh(7);
    expect(meanPairwiseDistance([genome, genome.deepCopy()])).toBeCloseTo(0);
  });

  it('positive when divergent', () => {
    const base = _fresh(8);
    const mutant = base.deepCopy();
    InnovationCounter().reset();
    InnovationCounter().syncTo(base.maxInnovation + 1);
    mutant._mutateAddNode();
    expect(meanPairwiseDistance([base, mutant])).toBeGreaterThan(0);
  });
});