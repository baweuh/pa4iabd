// ═══════════════════════════════════════════════════════════
//  Tests Agent manquants — port poc2.2 (étapes 4 + 7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect, beforeEach } from 'vitest';
import { Genome, SeededRNG, InnovationCounter } from '@/lib/alife/genome';
import { Agent } from '@/lib/alife/agent';
import { Environment } from '@/lib/alife/environment';
import { DEFAULT_CONFIG } from '@/lib/alife/config';

const cfg = DEFAULT_CONFIG;
const NUM_INPUTS = 49;
const NUM_OUTPUTS = 2;

let env: Environment;

beforeEach(() => {
  InnovationCounter().reset();
  env = new Environment(cfg.environment, new SeededRNG(42));
});

function makeAgent(x: number, y: number, heading?: number, energy?: number): Agent {
  InnovationCounter().reset();
  const genome = new Genome(NUM_INPUTS, NUM_OUTPUTS, new SeededRNG(0));
  return new Agent(genome, x, y, energy ?? cfg.agents.bootstrap_initial_energy,
    cfg.agents, cfg.mutations, new SeededRNG(0), true, heading);
}

describe('Agent — tests manquants (step 4+7)', () => {
  // ── test_ray_hits_apple ──
  it('ray_hits_apple: apple in front is detected', () => {
    const a = makeAgent(400, 400, 0);
    // Placer une pomme pile devant (heading=0 → +x)
    env.apples[0].x = 430;
    env.apples[0].y = 400;
    env.apples[0].respawn_at_tick = -1;
    const inputs = a.computeRaycasts(env);
    // Au moins un rayon doit voir la pomme
    const sawApple = inputs.slice(16, 32).some(v => v === 1);
    expect(sawApple).toBe(true);
    // La distance du rayon qui voit la pomme doit être < 1
    const hitDist = inputs.findIndex((_, i) => i < 16 && inputs[i] < 1.0);
    expect(hitDist).toBeGreaterThanOrEqual(0);
  });

  // ── test_apple_occludes_farther_wall ──
  it('apple occludes farther wall: apple flag wins over wall flag', () => {
    // Agent près du mur, pomme entre l'agent et le mur
    const a = makeAgent(cfg.environment.env_width - 100, 400, 0);
    // Pomme à 30px devant l'agent
    env.apples[0].x = cfg.environment.env_width - 70;
    env.apples[0].y = 400;
    env.apples[0].respawn_at_tick = -1;
    const inputs = a.computeRaycasts(env);
    // Le rayon 0 (avant) devrait voir la pomme, pas le mur
    // apple_flag[0] = 1 ET wall_flag[0] = 0 (pomme plus proche que mur)
    expect(inputs[16]).toBe(1); // apple flag ray 0
    expect(inputs[32]).toBe(0); // wall flag ray 0 (pomme occlut le mur)
  });

  // ── test_metabolize_penalty_zone ──
  it('metabolize in penalty zone drains more', () => {
    const a = makeAgent(5, 400); // Dans la zone pénalité
    const a2 = makeAgent(400, 400); // Zone sûre
    const drain1Start = a.energy;
    const drain2Start = a2.energy;
    a.applyEnergyDrain(env);
    a2.applyEnergyDrain(env);
    const drain1 = drain1Start - a.energy;
    const drain2 = drain2Start - a2.energy;
    expect(drain1).toBeGreaterThan(drain2);
  });

  // ── test_eat_caps_at_max_energy ──
  it('eat caps energy at max_energy', () => {
    const a = makeAgent(400, 400, undefined, cfg.agents.max_energy - 0.5);
    a.eat(cfg.environment.food_energy);
    // Avec le cap, l'énergie ne doit pas dépasser max_energy
    expect(a.energy).toBeLessThanOrEqual(cfg.agents.max_energy);
    expect(a.energy).toBe(cfg.agents.max_energy);
  });

  // ── test_activate_deterministic ──
  // Note: micro-noise (Math.random) rend think() non-déterministe quand output=0.
  // La déterminisme du réseau est testée dans network.test.ts.
  it('think produces finite vx, vy and valid heading', () => {
    InnovationCounter().reset();
    const rng = new SeededRNG(42);
    const genome = new Genome(NUM_INPUTS, NUM_OUTPUTS, rng);
    const a = new Agent(genome, 400, 400, cfg.agents.bootstrap_initial_energy,
      cfg.agents, cfg.mutations, new SeededRNG(0), true, 0);
    const inputs = a.computeRaycasts(env);
    a.think(inputs);
    expect(Number.isFinite(a.vx)).toBe(true);
    expect(Number.isFinite(a.vy)).toBe(true);
    expect(a.heading).toBeGreaterThanOrEqual(0);
    expect(a.heading).toBeLessThan(2 * Math.PI);
    const speed = Math.sqrt(a.vx ** 2 + a.vy ** 2);
    expect(speed).toBeLessThanOrEqual(cfg.agents.max_speed + 1e-9);
  });

  // ── test_child_spawns_near_parent ──
  it('child spawns within spawn_radius_child of parent', () => {
    const a = makeAgent(400, 400);
    a.energy = cfg.agents.reproduction_threshold;
    const child = a.reproduce(env, 0);
    const dx = child.x - a.x;
    const dy = child.y - a.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    expect(dist).toBeLessThanOrEqual(cfg.agents.spawn_radius_child + 1);
  });

  // ── test_energy_input_clamped_low ──
  it('energy input clamped to 0 when energy is negative', () => {
    const a = makeAgent(400, 400);
    a.energy = -5; // énergie négative (avant mort)
    const inputs = a.computeRaycasts(env);
    expect(inputs[48]).toBe(0); // clampé à 0 par max(0, ...)
  });

  // ── test_energy_input_clamped_high ──
  it('energy input clamped to 1 when energy exceeds max', () => {
    const a = makeAgent(400, 400);
    a.energy = cfg.agents.max_energy * 2;
    const inputs = a.computeRaycasts(env);
    expect(inputs[48]).toBe(1);
  });

  // ── test_heading_wraps_positive ──
  it('heading wraps correctly after multiple rotations', () => {
    const a = makeAgent(400, 400, Math.PI * 1.5);
    // Simuler plusieurs think() avec un grand turn
    const inputs = a.computeRaycasts(env);
    // Forcer un grand output de rotation via un réseau custom
    // On vérifie juste que heading reste dans [0, 2π)
    for (let i = 0; i < 50; i++) {
      a.computeRaycasts(env);
      a.think(inputs);
      expect(a.heading).toBeGreaterThanOrEqual(0);
      expect(a.heading).toBeLessThan(2 * Math.PI);
    }
  });

  // ── Vision dynamique (plasticité phénotypique) ──

  it('vision boost after eating: effectiveRayRange increases', () => {
    const a = makeAgent(400, 400);
    // Simuler la faim : avancer le compteur
    a.ticksSinceLastMeal = cfg.agents.vision_decay_ticks; // au minimum
    const rangeStarving = a.effectiveRayRange;
    // Manger reset le compteur → boost immédiat
    a.eat(cfg.environment.food_energy);
    a.ticksSinceLastMeal = 0;
    const rangeFed = a.effectiveRayRange;
    expect(rangeFed).toBeGreaterThan(rangeStarving);
    expect(rangeFed).toBeCloseTo(a.genome.ray_range * cfg.agents.vision_boost_max, 1);
  });

  it('vision decays over time without eating', () => {
    const a = makeAgent(400, 400);
    a.ticksSinceLastMeal = 0;
    const rangeFull = a.effectiveRayRange;
    // Avancer le compteur à moitié du decay
    a.ticksSinceLastMeal = Math.floor(cfg.agents.vision_decay_ticks / 2);
    const rangeHalf = a.effectiveRayRange;
    // Avancer au-delà du decay
    a.ticksSinceLastMeal = cfg.agents.vision_decay_ticks + 100;
    const rangeMin = a.effectiveRayRange;
    expect(rangeFull).toBeGreaterThan(rangeHalf);
    expect(rangeHalf).toBeGreaterThan(rangeMin);
    // Au minimum, le multiplicateur est vision_min_multiplier
    expect(rangeMin).toBeCloseTo(a.genome.ray_range * cfg.agents.vision_min_multiplier, 1);
  });

  it('eating resets ticksSinceLastMeal and boosts vision', () => {
    const a = makeAgent(400, 400);
    a.ticksSinceLastMeal = 500; // affamé
    a.eat(1.0);
    expect(a.ticksSinceLastMeal).toBe(0);
    expect(a.foodEaten).toBe(1);
  });

  it('applyEnergyDrain increments ticksSinceLastMeal', () => {
    const a = makeAgent(400, 400);
    a.ticksSinceLastMeal = 0;
    a.applyEnergyDrain(env);
    expect(a.ticksSinceLastMeal).toBe(1);
    a.applyEnergyDrain(env);
    expect(a.ticksSinceLastMeal).toBe(2);
  });

  it('lastSenses cache is populated after computeRaycasts', () => {
    const a = makeAgent(400, 400);
    expect(a.lastSenses.length).toBe(0);
    a.computeRaycasts(env);
    expect(a.lastSenses.length).toBe(NUM_INPUTS);
    // Le cache doit correspondre aux inputs retournés
    const inputs = a.computeRaycasts(env);
    expect(a.lastSenses).toEqual(inputs);
  });

  it('raycasts rotate with heading: different heading = different wall detection', () => {
    env.apples.length = 0;
    // Près du mur droit
    const a1 = makeAgent(cfg.environment.env_width - 50, 400, 0);   // regarde +x → voit mur
    const a2 = makeAgent(cfg.environment.env_width - 50, 400, Math.PI); // regarde -x → voit centre
    const inputs1 = a1.computeRaycasts(env);
    const inputs2 = a2.computeRaycasts(env);
    // a1 heading=0: ray 0 voit le mur → wall_flag[0]=1
    expect(inputs1[32]).toBe(1);
    // a2 heading=π: ray 0 regarde vers le centre → wall_flag[0]=0
    expect(inputs2[32]).toBe(0);
  });
});