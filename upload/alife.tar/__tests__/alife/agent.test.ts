// ═══════════════════════════════════════════════════════════
//  Tests Agent — port de test_agent.py (poc2.2 step 7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect, beforeEach } from 'vitest';
import { Genome, SeededRNG, InnovationCounter } from '@/lib/alife/genome';
import { Agent } from '@/lib/alife/agent';
import { Environment } from '@/lib/alife/environment';
import { DEFAULT_CONFIG } from '@/lib/alife/config';

const cfg = DEFAULT_CONFIG;
const NUM_INPUTS = 49;
const NUM_OUTPUTS = 2;

let env: Environment;
let rng: SeededRNG;

beforeEach(() => {
  InnovationCounter().reset();
  rng = new SeededRNG(42);
  env = new Environment(cfg.environment, rng);
});

function makeAgent(x: number, y: number, heading?: number): Agent {
  InnovationCounter().reset();
  const genome = new Genome(NUM_INPUTS, NUM_OUTPUTS, new SeededRNG(0));
  return new Agent(genome, x, y, cfg.agents.bootstrap_initial_energy, cfg.agents, cfg.mutations, new SeededRNG(0), true, heading);
}

// ── Heading égocentrique (step 4) ──

describe('Egocentric heading', () => {
  it('heading initialized explicitly', () => {
    const a = makeAgent(400, 400, 1.23);
    expect(a.heading).toBeCloseTo(1.23);
  });

  it('heading stays in [0, 2π) after think', () => {
    const a = makeAgent(400, 400, 0);
    a.computeRaycasts(env);
    a.think([0, 0]);
    expect(a.heading).toBeGreaterThanOrEqual(0);
    expect(a.heading).toBeLessThan(2 * Math.PI);
  });

  it('child inherits parent heading', () => {
    const a = makeAgent(400, 400, 0.5);
    a.energy = cfg.agents.reproduction_threshold;
    const child = a.reproduce(env, 0);
    expect(child.heading).toBeCloseTo(0.5);
  });
});

// ── Perception ──

describe('Agent perception', () => {
  it('sense returns 49 inputs', () => {
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    expect(inputs.length).toBe(NUM_INPUTS);
  });

  it('energy input normalized', () => {
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    const expected = cfg.agents.bootstrap_initial_energy / cfg.agents.max_energy;
    expect(inputs[NUM_INPUTS - 1]).toBeCloseTo(expected);
  });

  it('ray hits wall', () => {
    // Agent 50px from right wall, heading=0 → ray 0 points +x
    env.apples.length = 0;
    const a = makeAgent(cfg.environment.env_width - 50, 400, 0);
    const inputs = a.computeRaycasts(env);
    const n = cfg.agents.num_rays;
    // Ray 0 should see the wall
    expect(inputs[0]).toBeCloseTo(50 / a.effectiveRayRange, 1);
    expect(inputs[n]).toBe(0);        // apple flag
    expect(inputs[2 * n]).toBe(1);    // wall flag
  });

  it('ray sees nothing in center', () => {
    env.apples.length = 0;
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    const n = cfg.agents.num_rays;
    for (let i = 0; i < n; i++) {
      expect(inputs[i]).toBeCloseTo(1.0, 2);  // max normalised distance
      expect(inputs[n + i]).toBe(0);
      expect(inputs[2 * n + i]).toBe(0);
    }
  });
});

// ── Énergie ──

describe('Agent energy', () => {
  it('metabolize reduces energy in safe zone', () => {
    const a = makeAgent(400, 400);
    const start = a.energy;
    a.applyEnergyDrain(env);
    expect(a.energy).toBeLessThan(start);
  });

  it('eat gains energy', () => {
    const a = makeAgent(400, 400);
    a.eat(cfg.environment.food_energy);
    expect(a.energy).toBeCloseTo(cfg.agents.bootstrap_initial_energy + cfg.environment.food_energy);
  });
});

// ── Cycle de vie ──

describe('Agent life cycle', () => {
  it('dead by famine', () => {
    const a = makeAgent(400, 400);
    a.energy = 0;
    expect(a.isDead()).toBe(true);
  });

  it('dead by old age', () => {
    const a = makeAgent(400, 400);
    a.age = cfg.agents.max_lifespan;
    expect(a.isDead()).toBe(true);
  });

  it('alive when young and fed', () => {
    const a = makeAgent(400, 400);
    expect(a.isDead()).toBe(false);
  });

  it('can reproduce at threshold', () => {
    const a = makeAgent(400, 400);
    a.energy = cfg.agents.reproduction_threshold;
    expect(a.canReproduce()).toBe(true);
    a.energy = cfg.agents.reproduction_threshold - 0.01;
    expect(a.canReproduce()).toBe(false);
  });
});

// ── Reproduction ──

describe('Agent reproduction', () => {
  it('reproduce pays cost', () => {
    const a = makeAgent(400, 400);
    a.energy = cfg.agents.reproduction_threshold;
    a.reproduce(env, 0);
    expect(a.energy).toBeCloseTo(cfg.agents.parent_energy_after_repro);
  });

  it('child starts with initial energy', () => {
    const a = makeAgent(400, 400);
    a.energy = cfg.agents.reproduction_threshold;
    const child = a.reproduce(env, 0);
    expect(child.energy).toBeCloseTo(cfg.agents.child_initial_energy);
  });

  it('child is independent agent', () => {
    const a = makeAgent(400, 400);
    a.energy = cfg.agents.reproduction_threshold;
    const child = a.reproduce(env, 0);
    expect(child.network).not.toBe(a.network);
    expect(child.genome).not.toBe(a.genome);
    expect(child.age).toBe(0);
  });

  it('founder generation is zero', () => {
    const a = makeAgent(400, 400);
    expect(a.generation).toBe(0);
  });

  it('child generation increments', () => {
    const a = makeAgent(400, 400);
    a.generation = 4;
    a.energy = cfg.agents.reproduction_threshold;
    const child = a.reproduce(env, 0);
    // Le child reçoit generation=0 par défaut puis est incrémenté par simulation._checkReproduction
    // Dans reproduce() de Agent, la generation n'est pas encore passée au constructeur
    // C'est le Simulation qui fait child.generation = agent.generation + 1
    // Ici on vérifie juste que le parent a childrenCount++
    expect(a.childrenCount).toBe(1);
    expect(child.generation).toBe(0); // par défaut, simulation le mettra à jour
  });
});

// ── Mouvement ──

describe('Agent movement', () => {
  it('move clamped to world', () => {
    const a = makeAgent(cfg.agents.agent_radius + 1, 400);
    a.vx = -1000;
    a.vy = 0;
    a.move(env);
    expect(a.x).toBeCloseTo(cfg.agents.agent_radius);
  });

  it('velocity bounded by max_speed after think', () => {
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    a.think(inputs);
    const speed = Math.sqrt(a.vx ** 2 + a.vy ** 2);
    // tanh(speed_out) * max_speed → max is max_speed
    expect(speed).toBeLessThanOrEqual(cfg.agents.max_speed + 1e-9);
  });
});