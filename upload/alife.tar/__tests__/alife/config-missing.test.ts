// ═══════════════════════════════════════════════════════════
//  Tests Config manquants — port poc2.2 (étapes 1 + 7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect } from 'vitest';
import { DEFAULT_CONFIG, validateSimConfig, ConfigError } from '@/lib/alife/config';
import { loadConfigFromYaml, configFromDict } from '@/lib/alife/loader';
import * as fs from 'fs';

describe('Config — tests manquants (step 1+7)', () => {
  // ── test_from_dict : valeurs spécifiques depuis YAML ──
  it('from_dict: loaded values match expected', () => {
    const cfg = loadConfigFromYaml('config/default.yaml');
    expect(cfg.environment.env_width).toBe(800);
    expect(cfg.environment.env_height).toBe(800);
    expect(cfg.environment.zone_width).toBe(60);
    expect(cfg.agents.max_speed).toBe(2.0);
    expect(cfg.agents.num_rays).toBe(16);
    expect(cfg.agents.reproduction_threshold).toBe(5.0);
    expect(cfg.mutations.weight_max).toBe(5.0);
    expect(cfg.mutations.mutate_weights_prob).toBe(0.80);
    expect(cfg.population.max_population).toBe(150);
    expect(cfg.simulation.seed).toBe(42);
  });

  // ── test_missing_key ──
  it('missing key in section throws ConfigError', () => {
    const raw = {
      environment: { env_width: 800, env_height: 800, zone_width: 60, zone_max_drain: 0.05, food_count: 30, food_respawn_delay: 150, food_energy: 1.0 },
      agents: { initial_population: 30, max_speed: 2.0, base_drain_rate: 0.005, bootstrap_initial_energy: 4.0,
        // manquant: child_initial_energy
        reproduction_threshold: 5.0, parent_energy_after_repro: 1.0,
        max_lifespan: 10000, lifespan_warning_ticks: 500, agent_radius: 10, food_radius: 7,
        ray_max_range: 200, num_rays: 16, spawn_radius_child: 75, max_energy: 10.0, max_turn_rate: 0.2 },
      mutations: { mutate_weights_prob: 0.80, weight_perturb_prob: 0.15, weight_sigma: 0.2, weight_reset_prob: 0.05, weight_max: 5.0, add_connection_prob: 0.05, add_node_prob: 0.03, remove_connection_prob: 0.05, remove_node_prob: 0.02 },
      population: { initial_population: 30, max_population: 150 },
      speciation: { c_excess: 1.0, c_disjoint: 1.0, c_weight: 0.4, compatibility_threshold: 3.0 },
      simulation: { tick_rate: 60, render_fps: 60, log_interval: 100, seed: 42, headless: false },
    };
    expect(() => configFromDict(raw as any)).toThrow(/missing key/);
  });

  // ── test_invalid_yaml ──
  it('invalid YAML content throws ConfigError', () => {
    // Écrire un fichier YAML invalide temporairement
    const tmpPath = '/tmp/test_invalid.yaml';
    fs.writeFileSync(tmpPath, '{ not: valid: yaml: [', 'utf-8');
    try {
      expect(() => loadConfigFromYaml(tmpPath)).toThrow(ConfigError);
    } finally {
      fs.unlinkSync(tmpPath);
    }
  });

  // ── test_inputs_consistency ──
  it('input count matches 3 * num_rays + 1', () => {
    const cfg = DEFAULT_CONFIG;
    const expectedInputs = 3 * cfg.agents.num_rays + 1;
    expect(expectedInputs).toBe(49); // 16 * 3 + 1
  });

  // ── test_cross_validation_population (2-way: initial ≤ max) ──
  it('initial_population > max_population throws (2-way check)', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.population.initial_population = 200;
    raw.agents.initial_population = 200;
    expect(() => validateSimConfig(raw)).toThrow(/initial_population/);
  });

  // ── Logging validation : interval doit être positif ──
  it('logging interval ≤ 0 throws', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.logging = { csv_path: 'logs/metrics.csv', log_interval_ticks: 0, best_genome_path: 'x.json' };
    expect(() => validateSimConfig(raw)).toThrow(/must be > 0/);
  });

  // ── Logging validation : best_genome_path vide ──
  it('empty best_genome_path throws', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.logging = { csv_path: 'logs/metrics.csv', log_interval_ticks: 100, best_genome_path: '' };
    expect(() => validateSimConfig(raw)).toThrow(/best_genome_path/);
  });
});