// ═══════════════════════════════════════════════════════════
//  Tests Config — port de test_config.py (poc2.2 step 7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect } from 'vitest';
import { DEFAULT_CONFIG, validateSimConfig, ConfigError } from '@/lib/alife/config';
import { loadConfigFromYaml, configFromDict } from '@/lib/alife/loader';

describe('Config', () => {
  it('default config passes validation', () => {
    expect(() => validateSimConfig(DEFAULT_CONFIG)).not.toThrow();
  });

  it('loadConfigFromYaml loads default.yaml', () => {
    const cfg = loadConfigFromYaml('config/default.yaml');
    expect(cfg.agents.max_speed).toBe(2.0);
    expect(cfg.agents.num_rays).toBe(16);
    expect(cfg.agents.max_turn_rate).toBe(0.2);
    expect(cfg.mutations.weight_max).toBe(5.0);
  });

  it('loadConfigFromYaml throws on missing file', () => {
    expect(() => loadConfigFromYaml('does/not/exist.yaml')).toThrow(ConfigError);
  });

  it('missing section throws ConfigError', () => {
    const raw = { environment: { env_width: 800, env_height: 800, zone_width: 60, zone_max_drain: 0.05, food_count: 30, food_respawn_delay: 150, food_energy: 1.0 } };
    expect(() => configFromDict(raw as any)).toThrow(/missing config section/);
  });

  it('unknown key throws ConfigError', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    (raw as any).agents.bogus = 1;
    expect(() => configFromDict(raw as any)).toThrow(/unknown key/);
  });

  it('negative max_speed throws ConfigError', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.agents.max_speed = -1.0;
    expect(() => validateSimConfig(raw)).toThrow(/must be > 0/);
  });

  it('rate out of [0,1] throws ConfigError', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.mutations.mutate_weights_prob = 1.5;
    expect(() => validateSimConfig(raw)).toThrow(/must be in \[0, 1\]/);
  });

  it('zone too large throws ConfigError', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.environment.zone_width = 10000;
    expect(() => validateSimConfig(raw)).toThrow(/zone_width/);
  });

  it('parent_energy >= threshold throws ConfigError', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.agents.parent_energy_after_repro = raw.agents.reproduction_threshold;
    expect(() => validateSimConfig(raw)).toThrow(/parent_energy_after_repro/);
  });

  it('max_energy < bootstrap throws ConfigError', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.agents.max_energy = 1.0;
    expect(() => validateSimConfig(raw)).toThrow(/max_energy/);
  });

  it('initial_population > max_population throws ConfigError', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.population.initial_population = 200;
    raw.agents.initial_population = 200;
    expect(() => validateSimConfig(raw)).toThrow(/initial_population/);
  });

  it('logging validation', () => {
    const raw = structuredClone(DEFAULT_CONFIG);
    raw.logging = { csv_path: '', log_interval_ticks: 100, best_genome_path: 'x.json' };
    expect(() => validateSimConfig(raw)).toThrow(/csv_path/);
  });
});