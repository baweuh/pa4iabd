// ═══════════════════════════════════════════════════════════
//  Vérification spécifique des 4 étapes de fusion implémentées
//  Ce script teste de façon approfondie chaque étape :
//    - Étape 2 : Spéciation + métriques (species count, forage rate)
//    - Étape 3 : Elite injection + ceiling selection
//    - Étape 5 : Encodage 3-canaux (dist + apple_flag + wall_flag)
//    - Étape 8 : Weight clamping + output protection
// ═══════════════════════════════════════════════════════════

import { describe, it, expect, beforeEach } from 'vitest';
import { Genome, SeededRNG, InnovationCounter, NodeType } from '@/lib/alife/genome';
import { NeuralNetwork } from '@/lib/alife/network';
import { Agent } from '@/lib/alife/agent';
import { Environment } from '@/lib/alife/environment';
import { Simulation } from '@/lib/alife/simulation';
import { DEFAULT_CONFIG } from '@/lib/alife/config';
import { loadConfigFromYaml } from '@/lib/alife/loader';

// ─────────────────────────────────────────────────────────
//  ÉTAPE 5 : Encodage 3-canaux par rayon
//  Attendu : 49 inputs = 16 rays × 3 canaux + 1 énergie
//    - inputs[0..15]   = distances normalisées (0→1)
//    - inputs[16..31]  = apple flags (0.0 ou 1.0)
//    - inputs[32..47]  = wall flags  (0.0 ou 1.0)
//    - inputs[48]      = énergie normalisée
// ─────────────────────────────────────────────────────────

describe('ÉTAPE 5 — Encodage 3-canaux', () => {
  let env: Environment;
  const cfg = DEFAULT_CONFIG;

  beforeEach(() => {
    InnovationCounter().reset();
    env = new Environment(cfg.environment, new SeededRNG(42));
  });

  function makeAgent(x: number, y: number, heading?: number): Agent {
    InnovationCounter().reset();
    const genome = new Genome(49, 2, new SeededRNG(0));
    return new Agent(genome, x, y, cfg.agents.bootstrap_initial_energy,
      cfg.agents, cfg.mutations, new SeededRNG(0), true, heading);
  }

  it('49 inputs exactement (16×3 + 1)', () => {
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    expect(inputs.length).toBe(49);
  });

  it('canal distance : valeurs dans [0, 1] (normalisé)', () => {
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    for (let i = 0; i < 16; i++) {
      expect(inputs[i]).toBeGreaterThanOrEqual(0);
      expect(inputs[i]).toBeLessThanOrEqual(1.0 + 1e-9);
    }
  });

  it('canal apple_flag : que des 0 ou 1', () => {
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    for (let i = 16; i < 32; i++) {
      expect([0, 1]).toContain(inputs[i]);
    }
  });

  it('canal wall_flag : que des 0 ou 1', () => {
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    for (let i = 32; i < 48; i++) {
      expect([0, 1]).toContain(inputs[i]);
    }
  });

  it('input[48] = énergie normalisée (energy / max_energy)', () => {
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    const expected = cfg.agents.bootstrap_initial_energy / cfg.agents.max_energy;
    expect(inputs[48]).toBeCloseTo(expected);
  });

  it('raycast égocentrique : ray 0 = direction du heading (mur)', () => {
    env.apples.length = 0;
    // Agent près du mur droit, heading = 0 → regarde vers +x
    const a = makeAgent(cfg.environment.env_width - 50, 400, 0);
    const inputs = a.computeRaycasts(env);
    // Ray 0 = direction heading (0) = vers le mur droit
    expect(inputs[0]).toBeLessThan(1.0);
    expect(inputs[16]).toBe(0);   // apple flag ray 0
    expect(inputs[32]).toBe(1);   // wall flag ray 0
  });

  it('raycast égocentrique : heading=π → ray 0 voit le mur gauche', () => {
    env.apples.length = 0;
    const a = makeAgent(50, 400, Math.PI);
    const inputs = a.computeRaycasts(env);
    expect(inputs[0]).toBeLessThan(1.0);
    expect(inputs[32]).toBe(1);
  });

  it('raycast voit une pomme → apple_flag=1', () => {
    const a = makeAgent(400, 400, 0);
    env.apples[0].x = 440;
    env.apples[0].y = 400;
    env.apples[0].respawn_at_tick = -1;
    const inputs = a.computeRaycasts(env);
    const sawApple = inputs.slice(16, 32).some(v => v === 1);
    expect(sawApple).toBe(true);
  });

  it('pas de pomme → tous les apple_flags = 0', () => {
    env.apples.length = 0;
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    for (let i = 16; i < 32; i++) {
      expect(inputs[i]).toBe(0);
    }
  });

  it('au centre du monde, loin des murs → tous les wall_flags = 0', () => {
    env.apples.length = 0;
    const a = makeAgent(400, 400);
    const inputs = a.computeRaycasts(env);
    for (let i = 32; i < 48; i++) {
      expect(inputs[i]).toBe(0);
    }
  });
});

// ─────────────────────────────────────────────────────────
//  ÉTAPE 8 : Weight clamping (weight_max=5.0) + output protection
//  Attendu :
//    - Après mutation, |weight| <= weight_max (5.0)
//    - Les outputs ne sont jamais déconnectés (tjrs ≥1 connexion active)
//    - Même après remove_connection, remove_node, toggle : outputs protégés
// ─────────────────────────────────────────────────────────

describe('ÉTAPE 8 — Weight clamping + output protection', () => {
  const cfg = DEFAULT_CONFIG;
  const mutCfg = cfg.mutations;

  beforeEach(() => {
    InnovationCounter().reset();
  });

  function makeGenome(seed = 42): Genome {
    InnovationCounter().reset();
    return new Genome(49, 2, new SeededRNG(seed));
  }

  it('weight_max = 5.0 dans la config', () => {
    expect(cfg.mutations.weight_max).toBe(5.0);
  });

  it('poids initialisés dans [-1, 1]', () => {
    const g = makeGenome();
    for (const c of g.connections.values()) {
      expect(c.weight).toBeGreaterThanOrEqual(-1);
      expect(c.weight).toBeLessThanOrEqual(1);
    }
  });

  it('après 50 mutations : tous les poids clamped dans [-5, +5]', () => {
    const g = makeGenome(42);
    for (const c of g.connections.values()) {
      c.weight = 100.0;
    }
    for (let i = 0; i < 50; i++) {
      g.mutate(mutCfg);
    }
    for (const c of g.connections.values()) {
      expect(Math.abs(c.weight)).toBeLessThanOrEqual(mutCfg.weight_max);
    }
  });

  it('après 100 mutations : chaque output a ≥1 connexion active', () => {
    const g = makeGenome(42);
    for (let i = 0; i < 100; i++) {
      g.mutate(mutCfg);
      for (const oid of g.outputIds) {
        const activeIncoming = [...g.connections.values()].filter(
          c => c.enabled && c.out_node_id === oid
        ).length;
        expect(activeIncoming).toBeGreaterThanOrEqual(1);
      }
    }
  });

  it('remove_connection protège les outputs (200 itérations)', () => {
    const g = makeGenome(7);
    for (let i = 0; i < 200; i++) {
      g._mutateRemoveConnection();
      for (const oid of g.outputIds) {
        const activeIncoming = [...g.connections.values()].filter(
          c => c.enabled && c.out_node_id === oid
        ).length;
        expect(activeIncoming).toBeGreaterThanOrEqual(1);
      }
    }
  });

  it('remove_node protège les outputs (100 itérations)', () => {
    const g = makeGenome(8);
    for (let i = 0; i < 100; i++) {
      g._mutateRemoveNode();
      for (const oid of g.outputIds) {
        const activeIncoming = [...g.connections.values()].filter(
          c => c.enabled && c.out_node_id === oid
        ).length;
        expect(activeIncoming).toBeGreaterThanOrEqual(1);
      }
    }
  });

  it('toggle_connections protège les outputs (100 itérations)', () => {
    const g = makeGenome(9);
    for (let i = 0; i < 100; i++) {
      g._mutateToggleConnections();
      for (const oid of g.outputIds) {
        const activeIncoming = [...g.connections.values()].filter(
          c => c.enabled && c.out_node_id === oid
        ).length;
        expect(activeIncoming).toBeGreaterThanOrEqual(1);
      }
    }
  });

  it('genome fraîchement construit : 49 connexions par output', () => {
    const g = makeGenome(42);
    const outputIds = g.outputIds;
    expect(outputIds.length).toBe(2);
    for (const oid of outputIds) {
      const incoming = [...g.connections.values()].filter(c => c.out_node_id === oid && c.enabled);
      expect(incoming.length).toBe(49);
    }
  });
});

// ─────────────────────────────────────────────────────────
//  ÉTAPE 2 : Spéciation (NEAT compatibility distance) + métriques
//  Attendu :
//    - δ = c_excess*E + c_disjoint*D + c_weight*W̄
//    - Clones → distance = 0
//    - Mutation structurelle → distance > 0
//    - SimState contient speciesCount, meanGeneticDistance, forageRate
// ─────────────────────────────────────────────────────────

describe('ÉTAPE 2 — Spéciation + métriques', () => {
  beforeEach(() => {
    InnovationCounter().reset();
  });

  it('config speciation values are set', () => {
    expect(DEFAULT_CONFIG.speciation.c_excess).toBe(1.0);
    expect(DEFAULT_CONFIG.speciation.c_disjoint).toBe(1.0);
    expect(DEFAULT_CONFIG.speciation.c_weight).toBe(0.4);
    expect(DEFAULT_CONFIG.speciation.compatibility_threshold).toBe(3.0);
  });

  it('SimState exposes speciation metrics', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const state = sim.getState();
    expect('speciesCount' in state).toBe(true);
    expect('meanGeneticDistance' in state).toBe(true);
    expect('meanForageRate' in state).toBe(true);
    expect('maxForageRate' in state).toBe(true);
    expect('maxGeneration' in state).toBe(true);
  });

  it('30 clones au bootstrap → 1 seule espèce', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const state = sim.getState();
    expect(state.speciesCount).toBe(1);
  });

  it('meanGeneticDistance faible au démarrage (même topologie, poids seuls)', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const state = sim.getState();
    // Même topologie → pas d'excess/disjoint → distance = c_weight × avg_weight_diff
    // Seule la composante poids contribue (doit être < threshold)
    expect(state.meanGeneticDistance).toBeLessThan(DEFAULT_CONFIG.speciation.compatibility_threshold);
    expect(state.meanGeneticDistance).toBeGreaterThan(0);
  });

  it('meanForageRate = 0 au démarrage', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const state = sim.getState();
    expect(state.meanForageRate).toBe(0);
    expect(state.maxForageRate).toBe(0);
  });

  it('population initiale = 30', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const state = sim.getState();
    expect(state.population).toBe(30);
  });

  it('compatibility distance: clones → même innovation_ids et mêmes poids', () => {
    InnovationCounter().reset();
    const g1 = new Genome(33, 2, new SeededRNG(1));
    const g2 = g1.deepCopy();
    const weightsA = new Map<number, number>();
    const weightsB = new Map<number, number>();
    for (const c of g1.connections.values()) weightsA.set(c.innovation_id, c.weight);
    for (const c of g2.connections.values()) weightsB.set(c.innovation_id, c.weight);
    expect(weightsA.size).toBe(weightsB.size);
    let allMatch = true;
    for (const [k, v] of weightsA) {
      if (weightsB.get(k) !== v) allMatch = false;
    }
    expect(allMatch).toBe(true);
  });

  it('mutation structurelle → innovations excess apparaissent', () => {
    InnovationCounter().reset();
    const g1 = new Genome(33, 2, new SeededRNG(1));
    const g2 = g1.deepCopy();
    InnovationCounter().syncTo(g1.maxInnovation + 1);
    g2._mutateAddNode();
    const innovA = new Set([...g1.connections.values()].map(c => c.innovation_id));
    const innovB = new Set([...g2.connections.values()].map(c => c.innovation_id));
    const excess = [...innovB].filter(x => !innovA.has(x)).length;
    expect(excess).toBeGreaterThan(0);
  });
});

// ─────────────────────────────────────────────────────────
//  ÉTAPE 3 : Elite injection + ceiling selection
//  Attendu :
//    - max_population = 150, pas de dépassement
//    - Reproduction priorisée par énergie
//    - Clone non-muté du meilleur injecté au record
// ─────────────────────────────────────────────────────────

describe('ÉTAPE 3 — Elite injection + ceiling selection', () => {
  it('max_population = 150, initial = 30', () => {
    expect(DEFAULT_CONFIG.population.max_population).toBe(150);
    expect(DEFAULT_CONFIG.population.initial_population).toBe(30);
  });

  it('population ne dépasse jamais max_population (500 ticks)', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    for (let t = 0; t < 500; t++) {
      sim.step();
    }
    const state = sim.getState();
    expect(state.population).toBeLessThanOrEqual(DEFAULT_CONFIG.population.max_population);
  });

  it('ceiling selection : agents énergétiques se reproduisent en premier', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    for (let i = 0; i < 5; i++) {
      sim.agents[i].energy = DEFAULT_CONFIG.agents.reproduction_threshold + 5;
    }
    for (let i = 5; i < sim.agents.length; i++) {
      sim.agents[i].energy = 0.5;
    }
    sim.step();
    let childrenFromTop5 = 0;
    for (let i = 0; i < 5; i++) {
      childrenFromTop5 += sim.agents[i].childrenCount;
    }
    expect(childrenFromTop5).toBeGreaterThan(0);
  });

  it('simulation déterministe avec même seed (100 ticks)', () => {
    const simA = new Simulation(DEFAULT_CONFIG, 42);
    const simB = new Simulation(DEFAULT_CONFIG, 42);
    for (let t = 0; t < 100; t++) {
      simA.step();
      simB.step();
    }
    const sA = simA.getState();
    const sB = simB.getState();
    expect(sA.population).toBe(sB.population);
    expect(sA.currentTick).toBe(sB.currentTick);
    expect(sA.recordApples).toBe(sB.recordApples);
    expect(sA.avgEnergy).toBe(sB.avgEnergy);
  });

  it('SimState contient toutes les métriques attendues', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const state = sim.getState();
    const expectedKeys = [
      'currentTick', 'population', 'foodAvailable', 'recordApples',
      'totalReproductions', 'avgEnergy', 'avgNetSize', 'avgLifespan',
      'bestAgentFood', 'bestAgentEnergy', 'bestAgentAge',
      'bestAgentChildren', 'bestAgentNetSize', 'running', 'seed',
      'ticksPerFrame', 'paused', 'maxGeneration', 'speciesCount',
      'meanGeneticDistance', 'meanForageRate', 'maxForageRate',
    ];
    for (const key of expectedKeys) {
      expect(key in state).toBe(true);
    }
  });
});

// ─────────────────────────────────────────────────────────
//  CONFIG YAML — Fichier YAML présent et correspond à DEFAULT_CONFIG
// ─────────────────────────────────────────────────────────

describe('CONFIG YAML — Correspondance YAML ↔ DEFAULT_CONFIG', () => {
  it('loader charge et valide le YAML', () => {
    const cfg = loadConfigFromYaml('config/default.yaml');
    expect(cfg.agents.max_speed).toBe(DEFAULT_CONFIG.agents.max_speed);
    expect(cfg.agents.num_rays).toBe(DEFAULT_CONFIG.agents.num_rays);
    expect(cfg.mutations.weight_max).toBe(DEFAULT_CONFIG.mutations.weight_max);
    expect(cfg.agents.max_turn_rate).toBe(DEFAULT_CONFIG.agents.max_turn_rate);
    expect(cfg.population.max_population).toBe(DEFAULT_CONFIG.population.max_population);
  });

  it('toutes les clés YAML correspondent aux valeurs par défaut', () => {
    const cfg = loadConfigFromYaml('config/default.yaml');
    for (const section of ['environment', 'agents', 'mutations', 'population', 'speciation', 'simulation'] as const) {
      const yamlSection = (cfg as any)[section];
      const defaultSection = (DEFAULT_CONFIG as any)[section];
      for (const key of Object.keys(defaultSection)) {
        expect(yamlSection[key]).toBe(defaultSection[key]);
      }
    }
  });
});

// ─────────────────────────────────────────────────────────
//  INTÉGRATION — Simulation 1000 ticks sans crash
// ─────────────────────────────────────────────────────────

describe('INTÉGRATION — Simulation 1000 ticks', () => {
  it('1000 ticks sans crash et population vivante', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    for (let t = 0; t < 1000; t++) {
      if (!sim.step()) break;
    }
    const state = sim.getState();
    expect(state.currentTick).toBe(1000);
    expect(state.population).toBeGreaterThanOrEqual(1);
    expect(state.population).toBeLessThanOrEqual(DEFAULT_CONFIG.population.max_population);
  });

  it('micro-noise débloque les outputs déconnectés', () => {
    InnovationCounter().reset();
    const rng = new SeededRNG(42);
    const g = new Genome(49, 2, rng);
    g.connections.clear();
    const nn = new NeuralNetwork(g);
    const outputs = nn.activate(new Array(49).fill(0));
    for (const o of outputs) {
      expect(Math.abs(o)).toBeGreaterThan(0);
    }
  });

  it('heading modifié par think() reste dans [0, 2π)', () => {
    InnovationCounter().reset();
    const env = new Environment(DEFAULT_CONFIG.environment, new SeededRNG(42));
    const genome = new Genome(49, 2, new SeededRNG(0));
    const a = new Agent(genome, 400, 400, 5, DEFAULT_CONFIG.agents,
      DEFAULT_CONFIG.mutations, new SeededRNG(0), true, 0);
    const inputs = a.computeRaycasts(env);
    a.think(inputs);
    expect(a.heading).toBeGreaterThanOrEqual(0);
    expect(a.heading).toBeLessThan(2 * Math.PI);
  });

  it('vision dynamique: agents qui mangent ont une portée visuelle plus grande', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    // Faire tourner 200 ticks pour que certains agents mangent
    for (let i = 0; i < 200; i++) sim.step();
    // Vérifier que les agents qui ont mangé ont un ticksSinceLastMeal = 0
    // et ceux qui n'ont pas mangé ont ticksSinceLastMeal > 0
    const eaters = sim.agents.filter(a => a.foodEaten > 0 && a.alive);
    const nonEaters = sim.agents.filter(a => a.foodEaten === 0 && a.alive);
    if (eaters.length > 0 && nonEaters.length > 0) {
      // Ceux qui viennent de manger devraient avoir un boost de vision
      // (ticksSinceLastMeal proche de 0)
      const avgTSLMeaters = eaters.reduce((s, a) => s + a.ticksSinceLastMeal, 0) / eaters.length;
      const avgTSLMNonEaters = nonEaters.reduce((s, a) => s + a.ticksSinceLastMeal, 0) / nonEaters.length;
      expect(avgTSLMeaters).toBeLessThan(avgTSLMNonEaters);
    }
  });

  it('eat() ne dépasse jamais max_energy dans une simulation', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    for (let i = 0; i < 500; i++) {
      sim.step();
      for (const a of sim.agents) {
        if (a.alive) {
          expect(a.energy).toBeLessThanOrEqual(DEFAULT_CONFIG.agents.max_energy + 1e-9);
        }
      }
    }
  });
});