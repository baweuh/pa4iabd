// ═══════════════════════════════════════════════════════════
//  Tests Genome manquants — port poc2.2 (étapes 7 + 8)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect, beforeEach } from 'vitest';
import { Genome, SeededRNG, InnovationCounter, NodeType } from '@/lib/alife/genome';
import { DEFAULT_CONFIG } from '@/lib/alife/config';

const NUM_INPUTS = 33;
const NUM_OUTPUTS = 2;
const mutCfg = DEFAULT_CONFIG.mutations;

beforeEach(() => {
  InnovationCounter().reset();
});

function makeGenome(seed = 42): Genome {
  InnovationCounter().reset();
  return new Genome(NUM_INPUTS, NUM_OUTPUTS, new SeededRNG(seed));
}

describe('Genome — tests manquants (step 7+8)', () => {
  // ── test_creates_cycle_detection ──
  it('add_connection detects and avoids cycles', () => {
    const g = makeGenome(10);
    // Ajouter un noeud caché
    g._mutateAddNode();
    const hiddens = g.hiddenIds;
    expect(hiddens.length).toBe(1);
    const hiddenId = hiddens[0];

    // Tenter de créer une connexion output → input (cycle)
    const inputId = g.inputIds[0];
    const outputId = g.outputIds[0];
    const keyOutputInput = g.connKey(outputId, inputId);
    const keyInputOutput = g.connKey(inputId, outputId);

    // La connexion existe déjà dans le sens input→output
    expect(g.connections.has(keyInputOutput)).toBe(true);

    // Ajouter 100 connexions — aucune ne doit créer de cycle
    for (let i = 0; i < 100; i++) {
      g._mutateAddConnection();
    }
    // Vérifier qu'il n'y a pas de self-loops
    for (const c of g.connections.values()) {
      expect(c.in_node_id).not.toBe(c.out_node_id);
    }
  });

  // ── test_remove_connection ──
  it('remove_connection removes a disabled connection (when not output-protected)', () => {
    const g = makeGenome(20);
    // Ajouter un noeud caché et désactiver une connexion vers lui
    g._mutateAddNode();
    const hiddenId = g.hiddenIds[0];
    const hiddenConn = [...g.connections.values()].find(c => c.out_node_id === hiddenId);
    if (!hiddenConn) return;
    hiddenConn.enabled = false;
    const key = g.connKey(hiddenConn.in_node_id, hiddenConn.out_node_id);
    for (let i = 0; i < 20; i++) {
      g._mutateRemoveConnection();
      if (!g.connections.has(key)) break;
    }
    expect(g.connections.has(key)).toBe(false);
  });

  // ── test_remove_node_removes_incident_edges ──
  it('remove_node removes node and cleans up connections when safe', () => {
    const g = makeGenome(30);
    // Ajouter 3 hidden nodes pour avoir de la marge
    g._mutateAddNode();
    g._mutateAddNode();
    g._mutateAddNode();
    // Tenter de supprimer — peut échouer si output protégé
    for (let i = 0; i < 10; i++) {
      if (g.hiddenIds.length === 0) break;
      const beforeNodes = g.nodes.size;
      g._mutateRemoveNode();
      if (g.nodes.size < beforeNodes) {
        // Un noeud supprimé → vérifier qu'aucune connexion orpheline
        const nodeIds = new Set(g.nodes.keys());
        for (const c of g.connections.values()) {
          expect(nodeIds.has(c.in_node_id)).toBe(true);
          expect(nodeIds.has(c.out_node_id)).toBe(true);
        }
        break;
      }
    }
  });

  // ── test_remove_node_no_hidden_returns_early ──
  it('remove_node does nothing when no hidden nodes', () => {
    const g = makeGenome(40);
    expect(g.hiddenIds.length).toBe(0);
    const sizeBefore = g.connections.size;
    const nodesBefore = g.nodes.size;
    g._mutateRemoveNode();
    expect(g.connections.size).toBe(sizeBefore);
    expect(g.nodes.size).toBe(nodesBefore);
  });

  // ── test_toggle_connections ──
  it('toggle_connections toggles enabled/disabled state', () => {
    const g = makeGenome(50);
    // Compter les enabled avant
    const enabledBefore = g.enabledConnections.length;
    // Appliquer toggle (prob 0.02 par connexion — sur beaucoup de connexions)
    // Forcer au moins un toggle en appelant beaucoup de fois
    let anyToggled = false;
    for (let i = 0; i < 500; i++) {
      const before = g.connections.get([...g.connections.keys()][0])?.enabled;
      g._mutateToggleConnections();
      const after = g.connections.get([...g.connections.keys()][0])?.enabled;
      if (before !== after) anyToggled = true;
    }
    // Avec 66 connexions et prob 0.02, après 500 appels, au moins un toggle
    // (pas garanti à 100% mais extrêmement probable)
    // On vérifie surtout que les outputs sont toujours protégés
    for (const oid of g.outputIds) {
      const activeIncoming = [...g.connections.values()].filter(
        c => c.enabled && c.out_node_id === oid
      ).length;
      expect(activeIncoming).toBeGreaterThanOrEqual(1);
    }
  });

  // ── test_weights_clamped_after_perturb_only ──
  it('weight perturbation alone clamps correctly', () => {
    const g = makeGenome(60);
    for (const c of g.connections.values()) {
      c.weight = 4.9; // Juste sous le max
    }
    // Perturber plusieurs fois
    for (let i = 0; i < 20; i++) {
      g._mutateWeights(mutCfg);
    }
    for (const c of g.connections.values()) {
      expect(Math.abs(c.weight)).toBeLessThanOrEqual(mutCfg.weight_max);
    }
  });

  // ── test_innovation_counter_syncTo ──
  it('syncTo only advances if value is higher', () => {
    InnovationCounter().reset();
    const ic = InnovationCounter();
    ic.nextId; // 1
    ic.nextId; // 2
    ic.syncTo(10); // avance à 10
    expect(ic.current).toBe(10);
    ic.syncTo(5); // ne recule pas
    expect(ic.current).toBe(10);
    const next = ic.nextId; // 11
    expect(next).toBe(11);
  });

  // ── test_add_connection_no_duplicates ──
  it('add_connection does not create duplicate edges', () => {
    const g = makeGenome(70);
    g._mutateAddNode();
    const keysBefore = new Set(g.connections.keys());
    for (let i = 0; i < 50; i++) {
      g._mutateAddConnection();
    }
    const keysAfter = new Set(g.connections.keys());
    // Chaque clé est unique
    expect(keysAfter.size).toBe(g.connections.size);
  });

  // ── test_json_round_trip_with_mutations ──
  it('JSON round-trip after mutations preserves topology', () => {
    const g = makeGenome(80);
    for (let i = 0; i < 20; i++) g.mutate(mutCfg);
    const json = g.toJSON();
    const restored = Genome.fromJSON(json);
    expect(restored.nodes.size).toBe(g.nodes.size);
    expect(restored.connections.size).toBe(g.connections.size);
    expect(restored.ray_range).toBe(g.ray_range);
    // Vérifier les mêmes noeuds
    for (const [id, node] of g.nodes) {
      expect(restored.nodes.has(id)).toBe(true);
      expect(restored.nodes.get(id)!.type).toBe(node.type);
    }
  });
});