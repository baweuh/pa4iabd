// ═══════════════════════════════════════════════════════════
//  Tests Environment — port de test_environment.py (poc2.2 step 7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect, beforeEach } from 'vitest';
import { Environment } from '@/lib/alife/environment';
import { SeededRNG } from '@/lib/alife/genome';
import { DEFAULT_CONFIG } from '@/lib/alife/config';

const envCfg = DEFAULT_CONFIG.environment;

describe('Environment', () => {
  let env: Environment;

  beforeEach(() => {
    env = new Environment(envCfg, new SeededRNG(42));
  });

  it('apple count matches config', () => {
    expect(env.apples.length).toBe(envCfg.food_count);
  });

  it('determinism', () => {
    const envA = new Environment(envCfg, new SeededRNG(42));
    const envB = new Environment(envCfg, new SeededRNG(42));
    for (let i = 0; i < envA.apples.length; i++) {
      expect(envA.apples[i].x).toBe(envB.apples[i].x);
      expect(envA.apples[i].y).toBe(envB.apples[i].y);
    }
  });

  it('food available counts active apples', () => {
    expect(env.foodAvailable).toBe(envCfg.food_count);
    // Eat one
    env.eatApple(0, 0);
    expect(env.foodAvailable).toBe(envCfg.food_count - 1);
  });

  it('respawn restores apple after delay', () => {
    env.eatApple(0, 100);
    // Not yet respawned
    env.respawnApples(100);
    expect(env.foodAvailable).toBe(envCfg.food_count - 1);
    // After delay
    env.respawnApples(100 + envCfg.food_respawn_delay);
    expect(env.foodAvailable).toBe(envCfg.food_count);
  });
});

// ── Penalty field ──

describe('Wall penalty', () => {
  let env: Environment;

  beforeEach(() => {
    env = new Environment(envCfg, new SeededRNG(42));
  });

  it('penalty at wall equals max_drain', () => {
    const penalty = env.wallPenaltyDrain(0, envCfg.env_height / 2);
    expect(penalty).toBeCloseTo(envCfg.zone_max_drain);
  });

  it('penalty gradient midpoint', () => {
    const zw = envCfg.zone_width;
    const penalty = env.wallPenaltyDrain(zw / 2, envCfg.env_height / 2);
    expect(penalty).toBeCloseTo(envCfg.zone_max_drain * 0.5);
  });

  it('penalty zero at boundary', () => {
    const penalty = env.wallPenaltyDrain(envCfg.zone_width, envCfg.env_height / 2);
    expect(penalty).toBeCloseTo(0);
  });

  it('penalty zero in safe zone', () => {
    const cx = envCfg.env_width / 2;
    const cy = envCfg.env_height / 2;
    expect(env.wallPenaltyDrain(cx, cy)).toBe(0);
  });

  it('penalty strictly decreasing', () => {
    const y = envCfg.env_height / 2;
    const zw = envCfg.zone_width;
    const distances = [0, zw * 0.25, zw * 0.5, zw * 0.75];
    const penalties = distances.map(d => env.wallPenaltyDrain(d, y));
    for (let i = 0; i < penalties.length - 1; i++) {
      expect(penalties[i]).toBeGreaterThan(penalties[i + 1]);
    }
  });
});