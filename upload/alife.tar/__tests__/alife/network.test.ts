// ═══════════════════════════════════════════════════════════
//  Tests Network — port de test_network.py (poc2.2 step 7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect } from 'vitest';
import { Genome, NodeType, InnovationCounter } from '@/lib/alife/genome';
import { NeuralNetwork } from '@/lib/alife/network';
import { SeededRNG } from '@/lib/alife/genome';
import { DEFAULT_CONFIG } from '@/lib/alife/config';

function _smallGenome(): Genome {
  // Hand-crafted: inputs 0,1 → hidden 4 → outputs 2,3
  InnovationCounter().reset();
  const ic = InnovationCounter();
  const g = Object.create(Genome.prototype) as Genome;
  g.num_inputs = 2;
  g.num_outputs = 2;
  g._rng = new SeededRNG(0);
  g._nextHiddenId = 5;
  g.ray_range = 100;
  g.nodes = new Map([
    [0, { id: 0, type: NodeType.INPUT, activation: 'tanh' }],
    [1, { id: 1, type: NodeType.INPUT, activation: 'tanh' }],
    [4, { id: 4, type: NodeType.HIDDEN, activation: 'tanh' }],
    [2, { id: 2, type: NodeType.OUTPUT, activation: 'tanh' }],
    [3, { id: 3, type: NodeType.OUTPUT, activation: 'tanh' }],
  ]);
  g.connections = new Map([
    ['0,4', { in_node_id: 0, out_node_id: 4, weight: 0.5, enabled: true, innovation_id: ic.nextId }],
    ['1,4', { in_node_id: 1, out_node_id: 4, weight: -1.0, enabled: true, innovation_id: ic.nextId }],
    ['4,2', { in_node_id: 4, out_node_id: 2, weight: 2.0, enabled: true, innovation_id: ic.nextId }],
    ['4,3', { in_node_id: 4, out_node_id: 3, weight: -0.5, enabled: true, innovation_id: ic.nextId }],
  ]);
  return g;
}

describe('NeuralNetwork', () => {
  it('known topology', () => {
    const g = _smallGenome();
    const nn = new NeuralNetwork(g);
    // h = tanh(0.5*1.0 + (-1.0)*0.5) = tanh(0) = 0
    // outputs are linear: vx=2*0=0, vy=-0.5*0=0
    // Note: micro-noise fallback may apply to exact-zero outputs
    const [vx, vy] = nn.activate([1.0, 0.5]);
    // h ≈ 0 → outputs ≈ 0 (with micro-noise tolerance)
    expect(Math.abs(vx)).toBeLessThan(0.15);
    expect(Math.abs(vy)).toBeLessThan(0.15);
  });

  it('known topology nonzero hidden', () => {
    const g = _smallGenome();
    const nn = new NeuralNetwork(g);
    // h = tanh(0.5*2.0 + (-1.0)*(-1.0)) = tanh(1+1) = tanh(2) ≈ 0.964
    const expectedH = Math.tanh(0.5 * 2.0 + (-1.0) * (-1.0));
    const [vx, vy] = nn.activate([2.0, -1.0]);
    // Output is linear (no activation on output nodes in our impl)
    // Since h ≠ 0, no micro-noise should be applied
    expect(vx).toBeCloseTo(2.0 * expectedH, 4);
    expect(vy).toBeCloseTo(-0.5 * expectedH, 4);
  });

  it('output independent of connection order', () => {
    // Build two identical genomes with different connection insertion order
    // but same topology — topological sort normalizes evaluation order
    const ic1 = InnovationCounter();
    ic1.reset();
    const g1 = _smallGenome();
    // Rebuild g2 with same connections in different order
    InnovationCounter().reset();
    const ic = InnovationCounter();
    const g = Object.create(Genome.prototype) as Genome;
    g.num_inputs = 2;
    g.num_outputs = 2;
    g._rng = new SeededRNG(0);
    g._nextHiddenId = 5;
    g.ray_range = 100;
    g.nodes = new Map([
      [0, { id: 0, type: NodeType.INPUT, activation: 'tanh' }],
      [1, { id: 1, type: NodeType.INPUT, activation: 'tanh' }],
      [4, { id: 4, type: NodeType.HIDDEN, activation: 'tanh' }],
      [2, { id: 2, type: NodeType.OUTPUT, activation: 'tanh' }],
      [3, { id: 3, type: NodeType.OUTPUT, activation: 'tanh' }],
    ]);
    // Same connections, same weights, different insertion order
    g.connections = new Map([
      ['4,2', { in_node_id: 4, out_node_id: 2, weight: 2.0, enabled: true, innovation_id: 2 }],
      ['1,4', { in_node_id: 1, out_node_id: 4, weight: -1.0, enabled: true, innovation_id: 1 }],
      ['4,3', { in_node_id: 4, out_node_id: 3, weight: -0.5, enabled: true, innovation_id: 3 }],
      ['0,4', { in_node_id: 0, out_node_id: 4, weight: 0.5, enabled: true, innovation_id: 0 }],
    ]);
    const nn1 = new NeuralNetwork(g1);
    const nn2 = new NeuralNetwork(g);
    // Both should produce the same output (topo sort normalizes)
    // Note: if h≈0, both outputs get micro-noise (random), so use loose tolerance
    const out1 = nn1.activate([1.0, 0.5]);
    const out2 = nn2.activate([1.0, 0.5]);
    // Both should be near-zero since h = tanh(0.5 - 0.5) = tanh(0) = 0
    expect(Math.abs(out1[0])).toBeLessThan(0.15);
    expect(Math.abs(out2[0])).toBeLessThan(0.15);
  });

  it('forward deterministic', () => {
    InnovationCounter().reset();
    const rng = new SeededRNG(42);
    const g = new Genome(33, 2, rng);
    const nn1 = new NeuralNetwork(g);
    const nn2 = new NeuralNetwork(g);
    const inputs = Array.from({ length: 33 }, (_, i) => i / 33);
    const out1a = nn1.activate(inputs);
    const out1b = nn1.activate(inputs);
    const out2 = nn2.activate(inputs);
    expect(out1a).toEqual(out1b);
    expect(out1a).toEqual(out2);
  });

  it('disabled connection ignored', () => {
    const g1 = _smallGenome();
    const g2 = _smallGenome();
    // Add extra connection in g1, disabled in g2
    const ic = InnovationCounter();
    g1.connections.set('0,2', { in_node_id: 0, out_node_id: 2, weight: 99.0, enabled: true, innovation_id: ic.nextId });
    g2.connections.set('0,2', { in_node_id: 0, out_node_id: 2, weight: 99.0, enabled: false, innovation_id: ic.nextId });
    const nn1 = new NeuralNetwork(g1);
    const nn2 = new NeuralNetwork(g2);
    const inputs = [1.0, 0.5];
    expect(nn1.activate(inputs)).not.toEqual(nn2.activate(inputs));
  });

  it('output with no incoming edges is zero (plus micro-noise)', () => {
    InnovationCounter().reset();
    const g = Object.create(Genome.prototype) as Genome;
    g.num_inputs = 1;
    g.num_outputs = 2;
    g._rng = new SeededRNG(0);
    g._nextHiddenId = 3;
    g.ray_range = 100;
    g.nodes = new Map([
      [0, { id: 0, type: NodeType.INPUT, activation: 'tanh' }],
      [1, { id: 1, type: NodeType.OUTPUT, activation: 'tanh' }],
      [2, { id: 2, type: NodeType.OUTPUT, activation: 'tanh' }],
    ]);
    g.connections = new Map();
    const nn = new NeuralNetwork(g);
    const [vx, vy] = nn.activate([1.0]);
    // Output 0 has no incoming → micro-noise fallback
    // Output 1 also has no incoming → micro-noise
    // Both should be very small
    expect(Math.abs(vx)).toBeLessThan(0.2);
    expect(Math.abs(vy)).toBeLessThan(0.2);
  });

  it('full network produces finite outputs', () => {
    InnovationCounter().reset();
    const rng = new SeededRNG(99);
    const g = new Genome(49, 2, rng);
    const nn = new NeuralNetwork(g);
    for (let i = 0; i < 10; i++) {
      const inputs = Array.from({ length: 49 }, () => rng.uniform(-1, 1));
      const [vx, vy] = nn.activate(inputs);
      expect(Number.isFinite(vx)).toBe(true);
      expect(Number.isFinite(vy)).toBe(true);
    }
  });
});