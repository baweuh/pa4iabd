// ═══════════════════════════════════════════════════════════
//  Tests Environment manquants — port poc2.2 (étape 7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect, beforeEach } from 'vitest';
import { Environment } from '@/lib/alife/environment';
import { SeededRNG } from '@/lib/alife/genome';
import { DEFAULT_CONFIG } from '@/lib/alife/config';

const envCfg = DEFAULT_CONFIG.environment;

describe('Environment — tests manquants (step 7)', () => {
  let env: Environment;

  beforeEach(() => {
    env = new Environment(envCfg, new SeededRNG(42));
  });

  // ── test_apples_full_body_in_safe_zone ──
  it('all apples spawn in safe zone', () => {
    const zw = envCfg.zone_width;
    const margin = 10; // margin used in _randomSafePosition
    for (const apple of env.apples) {
      expect(apple.x).toBeGreaterThan(zw + margin);
      expect(apple.x).toBeLessThan(envCfg.env_width - zw - margin);
      expect(apple.y).toBeGreaterThan(zw + margin);
      expect(apple.y).toBeLessThan(envCfg.env_height - zw - margin);
    }
  });

  // ── test_respawn_changes_position ──
  it('respawn changes apple position', () => {
    const apple = env.apples[0];
    const origX = apple.x;
    const origY = apple.y;
    env.eatApple(0, 0);
    env.respawnApples(0 + envCfg.food_respawn_delay);
    // La pomme a respawné — position peut changer
    // (pas garanti différent car aléatoire, mais très probable)
    expect(apple.respawn_at_tick).toBe(-1); // active
  });

  // ── test_respawn_stays_in_safe_zone ──
  it('respawned apple stays in safe zone', () => {
    const zw = envCfg.zone_width;
    const margin = 10;
    for (let i = 0; i < env.apples.length; i++) {
      env.eatApple(i, 0);
      env.respawnApples(envCfg.food_respawn_delay);
      expect(env.apples[i].x).toBeGreaterThan(zw + margin);
      expect(env.apples[i].y).toBeLessThan(envCfg.env_height - zw - margin);
    }
  });

  // ── test_mark_eaten_defers_respawn ──
  it('eatApple sets respawn timer correctly', () => {
    const apple = env.apples[0];
    env.eatApple(0, 100);
    expect(apple.respawn_at_tick).toBe(100 + envCfg.food_respawn_delay);
    expect(env.foodAvailable).toBe(envCfg.food_count - 1);
  });

  // ── test_respawn_noop_without_pending ──
  it('respawnApples does nothing when no pending respawns', () => {
    const countBefore = env.foodAvailable;
    env.respawnApples(999);
    expect(env.foodAvailable).toBe(countBefore);
  });

  // ── test_in_safe_zone_center ──
  it('center of world is in safe zone', () => {
    const cx = envCfg.env_width / 2;
    const cy = envCfg.env_height / 2;
    expect(env.isValidSpawn(cx, cy, 10)).toBe(true);
    expect(env.wallPenaltyDrain(cx, cy)).toBe(0);
  });

  // ── test_not_in_safe_zone_near_wall ──
  it('near wall is NOT valid spawn', () => {
    expect(env.isValidSpawn(5, 400, 10)).toBe(false);
    expect(env.isValidSpawn(400, 5, 10)).toBe(false);
    expect(env.isValidSpawn(envCfg.env_width - 5, 400, 10)).toBe(false);
  });

  // ── test_clamp_position ──
  it('clampPosition respects world bounds and radius', () => {
    const radius = 10;
    // Hors monde à gauche
    const [cx1, cy1] = env.clampPosition(-100, 400, radius);
    expect(cx1).toBe(radius);
    // Hors monde à droite
    const [cx2, cy2] = env.clampPosition(envCfg.env_width + 100, 400, radius);
    expect(cx2).toBe(envCfg.env_width - radius);
    // Position normale → non modifiée
    const [cx3, cy3] = env.clampPosition(400, 400, radius);
    expect(cx3).toBe(400);
    expect(cy3).toBe(400);
  });

  // ── test_penalty_corner ──
  it('corner has maximum penalty from two walls', () => {
    // Dans un coin, la distance au mur le plus proche est min(x, y)
    // Pas de double penalty — seul le mur le plus proche compte
    const penalty = env.wallPenaltyDrain(1, 1);
    expect(penalty).toBeCloseTo(envCfg.zone_max_drain);
  });
});