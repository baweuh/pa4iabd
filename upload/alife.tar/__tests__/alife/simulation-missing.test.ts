// ═══════════════════════════════════════════════════════════
//  Tests Simulation manquants — port poc2.2 (étapes 2+3+6+7)
// ═══════════════════════════════════════════════════════════

import { describe, it, expect } from 'vitest';
import { Simulation } from '@/lib/alife/simulation';
import { Genome, SeededRNG, InnovationCounter } from '@/lib/alife/genome';
import { DEFAULT_CONFIG } from '@/lib/alife/config';

describe('Simulation — tests manquants (step 2+3+6+7)', () => {
  // ── test_initial_agents_in_safe_zone ──
  it('all bootstrap agents spawn in safe zone', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const zw = DEFAULT_CONFIG.environment.zone_width;
    for (const agent of sim.agents) {
      expect(agent.x).toBeGreaterThan(zw);
      expect(agent.x).toBeLessThan(DEFAULT_CONFIG.environment.env_width - zw);
      expect(agent.y).toBeGreaterThan(zw);
      expect(agent.y).toBeLessThan(DEFAULT_CONFIG.environment.env_height - zw);
    }
  });

  // ── test_tick_advances_counter_and_ages ──
  it('each tick advances currentTick and agent age', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const age0 = sim.agents[0].age;
    sim.step();
    expect(sim.currentTick).toBe(1);
    expect(sim.agents[0].age).toBe(age0 + 1);
    sim.step();
    expect(sim.currentTick).toBe(2);
    expect(sim.agents[0].age).toBe(age0 + 2);
  });

  // ── test_tick_applies_metabolism ──
  it('each tick reduces agent energy (metabolism)', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const energyBefore = sim.agents[0].energy;
    sim.step();
    expect(sim.agents[0].energy).toBeLessThan(energyBefore);
  });

  // ── test_eating_removes_food_then_respawns ──
  it('food is removed when eaten and respawns after delay', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const foodBefore = sim.getState().foodAvailable;
    // Force un agent près d'une pomme
    const apple = sim.env.apples[0];
    if (apple.respawn_at_tick >= 0) return;
    sim.agents[0].x = apple.x;
    sim.agents[0].y = apple.y;
    for (let t = 0; t < 5; t++) sim.step();
    // Au moins une pomme a été mangée pendant la simulation
    // (d'autres agents mangent aussi pendant 160+ ticks)
    expect(sim.env.foodAvailable).toBeLessThanOrEqual(foodBefore);
  });

  // ── test_reproduction_increments_and_respects_cap ──
  it('reproduction increases population but respects cap', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    // Donner beaucoup d'énergie à tous les agents
    for (const agent of sim.agents) {
      agent.energy = DEFAULT_CONFIG.agents.reproduction_threshold + 10;
    }
    // Laisser tourner quelques ticks
    for (let t = 0; t < 10; t++) sim.step();
    expect(sim.totalReproductions).toBeGreaterThan(0);
    expect(sim.agents.length).toBeLessThanOrEqual(DEFAULT_CONFIG.population.max_population);
  });

  // ── test_extinction_stops_run ──
  it('extinction stops the simulation', () => {
    // Créer une config avec drain énorme pour tuer tout le monde vite
    const cfg = structuredClone(DEFAULT_CONFIG);
    cfg.agents.base_drain_rate = 10.0;   // drain massif
    cfg.agents.bootstrap_initial_energy = 0.1;
    const sim = new Simulation(cfg, 42);
    for (let t = 0; t < 200; t++) {
      if (!sim.step()) break;
    }
    expect(sim.running).toBe(false);
    expect(sim.agents.length).toBe(0);
  });

  // ── test_csv_header_and_rows (step 6) ──
  it('CSV has correct header and rows at configured interval', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const interval = sim['_logInterval']; // 100 par défaut
    // Avant le premier interval → seul le header
    const csvBefore = sim.getCsvContent();
    const linesBefore = csvBefore.split('\n');
    expect(linesBefore.length).toBe(1); // header only
    expect(linesBefore[0]).toContain('tick,population,food_available');

    // Avancer jusqu'au premier log
    for (let t = 0; t < interval; t++) sim.step();
    const csvAfter = sim.getCsvContent();
    const linesAfter = csvAfter.split('\n');
    expect(linesAfter.length).toBe(2); // header + 1 row
    // Vérifier que la ligne de données a les bonnes colonnes
    const cols = linesAfter[1].split(',');
    expect(cols.length).toBe(13);
    expect(parseInt(cols[0])).toBe(interval); // tick
    expect(parseInt(cols[1])).toBeGreaterThan(0); // population
  });

  // ── test_csv_has_evolutionary_columns (step 6) ──
  it('CSV includes evolutionary columns', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    for (let t = 0; t < 100; t++) sim.step();
    const csv = sim.getCsvContent();
    const header = csv.split('\n')[0];
    expect(header).toContain('species_count');
    expect(header).toContain('mean_genetic_distance');
    expect(header).toContain('mean_forage_rate');
    expect(header).toContain('max_forage_rate');
    expect(header).toContain('max_generation');
    expect(header).toContain('mean_generation');
  });

  // ── test_csv_interval_respected (step 6) ──
  it('CSV logs at configured interval, not every tick', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    // 150 ticks → 1 row (à 100) + header
    for (let t = 0; t < 150; t++) sim.step();
    const lines = sim.getCsvContent().split('\n');
    expect(lines.length).toBe(2); // header + 1 row à tick 100

    // 250 ticks → 2 rows (à 100 et 200)
    for (let t = 150; t < 250; t++) sim.step();
    const lines2 = sim.getCsvContent().split('\n');
    expect(lines2.length).toBe(3); // header + 2 rows
    expect(lines2[2].split(',')[0]).toBe('200');
  });

  // ── test_best_genome_saved_on_record (step 6) ──
  it('best genome snapshot saved when record is broken', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    // Au bootstrap, recordApples = 0 → le premier agent qui mange bat le record
    // Forcer un agent à manger
    const apple = sim.env.apples[0];
    sim.agents[0].x = apple.x;
    sim.agents[0].y = apple.y;
    for (let t = 0; t < 5; t++) sim.step();
    // Si un record a été battu, un snapshot JSON existe
    if (sim.recordApples > 0) {
      const snapshots = sim.getBestGenomeSnapshots();
      expect(snapshots.length).toBeGreaterThan(0);
      // Le snapshot est du JSON valide
      const parsed = JSON.parse(snapshots[0]);
      expect(parsed.num_inputs).toBe(49);
      expect(parsed.num_outputs).toBe(2);
      expect(parsed.nodes).toBeDefined();
      expect(parsed.connections).toBeDefined();
    }
  });

  // ── test_elite_reinjected_on_record (step 3) ──
  it('elite injection adds an extra agent on record', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const popBefore = sim.agents.length;
    // Placer un agent sur une pomme
    const apple = sim.env.apples[0];
    sim.agents[0].x = apple.x;
    sim.agents[0].y = apple.y;
    sim.step();
    sim.step();
    // Si un record a été battu, la population a augmenté (elite + reproduction)
    // ou au moins n'a pas baissé
    const popAfter = sim.agents.length;
    expect(popAfter).toBeGreaterThanOrEqual(popBefore);
  });

  // ── test_multi_offspring_high_energy (step 3) ──
  it('high energy agent can produce multiple children', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    const agent = sim.agents[0];
    agent.energy = DEFAULT_CONFIG.agents.reproduction_threshold + 20;
    const childrenBefore = agent.childrenCount;
    // Plusieurs ticks pour permettre reproduction
    for (let t = 0; t < 5; t++) sim.step();
    expect(agent.childrenCount).toBeGreaterThan(childrenBefore);
  });

  // ── test_divergent_genomes_form_multiple_species (step 2) ──
  it('divergent genomes form multiple species', () => {
    const specCfg = DEFAULT_CONFIG.speciation;
    InnovationCounter().reset();
    const base = new Genome(33, 2, new SeededRNG(1));
    const genomes = [base];
    for (let i = 0; i < 3; i++) {
      const mutant = base.deepCopy();
      InnovationCounter().syncTo(base.maxInnovation + 1);
      for (let j = 0; j < 20; j++) {
        mutant._mutateAddNode();
        mutant._mutateAddConnection();
      }
      genomes.push(mutant);
    }
    // Compter les espèces avec la même logique que simulation._countSpecies
    const representatives: any[] = [];
    for (const genome of genomes) {
      const isNovel = !representatives.some((rep: any) => {
        const wA = new Map([...genome.connections.values()].map((c: any) => [c.innovation_id, c.weight]));
        const wB = new Map([...rep.connections.values()].map((c: any) => [c.innovation_id, c.weight]));
        if (wA.size === 0 && wB.size === 0) return true;
        const iA = new Set(wA.keys()), iB = new Set(wB.keys());
        const matching = new Set([...iA].filter((x: number) => iB.has(x)));
        const maxA = wA.size > 0 ? Math.max(...iA) : -1;
        const maxB = wB.size > 0 ? Math.max(...iB) : -1;
        const boundary = Math.min(maxA, maxB);
        let excess = 0, disjoint = 0;
        for (const innov of [...iA, ...iB]) {
          if (matching.has(innov)) continue;
          if (innov > boundary) excess++; else disjoint++;
        }
        let wd = 0;
        if (matching.size > 0) {
          let td = 0;
          for (const innov of matching) td += Math.abs(wA.get(innov)! - wB.get(innov)!);
          wd = td / matching.size;
        }
        const d = specCfg.c_excess * excess + specCfg.c_disjoint * disjoint + specCfg.c_weight * wd;
        return d < specCfg.compatibility_threshold;
      });
      if (isNovel) representatives.push(genome);
    }
    expect(representatives.length).toBeGreaterThan(1);
  });

  // ── test_two_empty_genomes_distance_zero (step 2) ──
  it('compatibility distance handles edge cases', () => {
    // Testé indirectement via speciation.test.ts
    // La fonction _compatibilityDistance retourne 0 pour deux génomes vides
    // Ce test vérifie juste que la simulation ne crash pas avec des génomes vides
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    for (let t = 0; t < 10; t++) sim.step();
    expect(sim.getState().meanGeneticDistance).toBeGreaterThanOrEqual(0);
  });

  // ── test_network_input_length ──
  it('simulation uses 49 inputs matching config', () => {
    const sim = new Simulation(DEFAULT_CONFIG, 42);
    expect(sim.numInputs).toBe(49);
    expect(sim.numOutputs).toBe(2);
  });
});